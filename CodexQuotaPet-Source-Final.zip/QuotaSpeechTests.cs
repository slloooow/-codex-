using System;

namespace CodexQuotaPet
{
    internal static class QuotaSpeechTests
    {
        private static int _passed;
        private static readonly DateTime NowUtc =
            new DateTime(2026, 8, 31, 8, 0, 0, DateTimeKind.Utc);

        private static void Main()
        {
            ExpectQuota(100.0, "还有 100%，时间对我们很慷慨。", "100%", "100 percent");
            ExpectQuota(70.0, "还有 70%，时间对我们很慷慨。", "70%", "70 percent");
            ExpectQuota(69.0, "还剩 69%，再陪我一会儿吧～", "69%", "69 percent");
            ExpectQuota(40.0, "还剩 40%，再陪我一会儿吧～", "40%", "40 percent");
            ExpectQuota(39.0, "只剩 39% 了，别太勉强自己。", "39%", "39 percent");
            ExpectQuota(15.0, "只剩 15% 了，别太勉强自己。", "15%", "15 percent");
            ExpectQuota(14.0, "仅余 14%……留给重要的事吧。", "14%", "14 percent");
            ExpectQuota(1.0, "仅余 1%……留给重要的事吧。", "1%", "1 percent");
            ExpectQuota(0.0, "额度归零，问答暂时结束～", "0%", "zero percent");

            QuotaSpeechContent loading = QuotaSpeech.Build(
                null,
                false,
                true,
                "正在连接 Codex…",
                NowUtc);
            Expect("谜底在路上，再等我一下～", loading.Dialogue, "loading dialogue");
            Expect("…", loading.CompactText, "loading compact");

            QuotaSpeechContent stale = QuotaSpeech.Build(
                Snapshot(64.0),
                true,
                false,
                "连接已断开",
                NowUtc);
            Expect("信号藏起来了，我去找找～", stale.Dialogue, "stale dialogue");
            Expect("64%!", stale.CompactText, "stale cached compact");
            Expect("上次额度 64% · 等待更新", stale.Detail, "stale cached detail");

            QuotaSpeechContent unavailable = QuotaSpeech.Build(
                null,
                true,
                false,
                "找不到 Codex",
                NowUtc);
            Expect("!", unavailable.CompactText, "stale empty compact");
            Expect("信号藏起来了，我去找找～", unavailable.Dialogue, "stale empty dialogue");
            Expect("稍后会自动重试", unavailable.Detail, "stale empty detail");

            QuotaSpeechContent unlimited = QuotaSpeech.Build(
                UnlimitedSnapshot(),
                false,
                false,
                "额度已更新",
                NowUtc);
            Expect("∞", unlimited.CompactText, "unlimited compact");
            Expect("今天的时间对我们格外慷慨。", unlimited.Dialogue, "unlimited dialogue");
            Expect("当前没有额度限制", unlimited.Detail, "unlimited detail");

            QuotaSpeechContent staleUnlimited = QuotaSpeech.Build(
                UnlimitedSnapshot(),
                true,
                false,
                "连接已断开",
                NowUtc);
            Expect("∞!", staleUnlimited.CompactText, "stale unlimited compact");
            Expect("信号藏起来了，我去找找～", staleUnlimited.Dialogue, "stale unlimited dialogue");
            Expect("上次状态：无限 · 等待更新", staleUnlimited.Detail, "stale unlimited detail");

            QuotaSpeechContent weekly = QuotaSpeech.Build(
                new QuotaSnapshot
                {
                    RemainingPercent = 78.0,
                    WindowDurationMins = 10080.0,
                    WindowDisplayName = "周额度",
                    ResetAtUtc = NowUtc.AddDays(6).AddHours(2).AddMinutes(3).AddSeconds(4)
                },
                false,
                false,
                "额度已更新",
                NowUtc);
            Expect("6天 02:03:04 后重置", weekly.Detail, "weekly countdown");

            QuotaSpeechContent expired = QuotaSpeech.Build(
                new QuotaSnapshot
                {
                    RemainingPercent = 55.0,
                    ResetAtUtc = NowUtc.AddSeconds(-1)
                },
                false,
                false,
                "额度已更新",
                NowUtc);
            Expect("正在刷新额度…", expired.Detail, "expired reset");

            Console.WriteLine("PASS: " + _passed + " quota speech scenarios");
        }

        private static void ExpectQuota(
            double remaining,
            string dialogue,
            string compact,
            string name)
        {
            QuotaSpeechContent content = QuotaSpeech.Build(
                Snapshot(remaining),
                false,
                false,
                "额度已更新",
                NowUtc);
            Expect(dialogue, content.Dialogue, name + " dialogue");
            Expect(compact, content.CompactText, name + " compact");
            Expect("04:00:00 后重置", content.Detail, name + " countdown");
        }

        private static QuotaSnapshot Snapshot(double remaining)
        {
            return new QuotaSnapshot
            {
                UsedPercent = 100.0 - remaining,
                RemainingPercent = remaining,
                ResetAtUtc = NowUtc.AddHours(4),
                UpdatedAtUtc = NowUtc,
                WindowDurationMins = 300.0,
                WindowDisplayName = "5小时额度"
            };
        }

        private static QuotaSnapshot UnlimitedSnapshot()
        {
            return new QuotaSnapshot
            {
                UsedPercent = 0.0,
                RemainingPercent = 100.0,
                ResetAtUtc = DateTime.MaxValue,
                UpdatedAtUtc = NowUtc,
                WindowDurationMins = 0.0,
                WindowDisplayName = "无限",
                IsUnlimited = true
            };
        }

        private static void Expect(string expected, string actual, string name)
        {
            if (!String.Equals(expected, actual, StringComparison.Ordinal))
            {
                throw new Exception(name + ": expected '" + expected + "', actual '" + actual + "'");
            }
            _passed++;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace CodexQuotaPet
{
    internal sealed class PetForm : Form
    {
        public static readonly Color TransparencyColor = Color.FromArgb(0, 255, 0);

        private const int GwlExStyle = -20;
        private const int WsExTransparent = 0x00000020;

        private readonly PictureBox _petPicture;
        private readonly QuotaCard _quotaCard;
        private readonly Dictionary<string, Image> _images = new Dictionary<string, Image>();
        private readonly List<Stream> _imageStreams = new List<Stream>();
        private readonly AppServerClient _client;
        private readonly PetSettings _settings;
        private readonly NotifyIcon _trayIcon;
        private readonly ContextMenuStrip _menu;
        private readonly ToolStripMenuItem _clickThroughItem;
        private readonly ToolStripMenuItem _autoStartItem;
        private readonly ToolStripMenuItem _visibilityItem;
        private readonly ToolTip _toolTip;
        private readonly Timer _clockTimer;
        private readonly Timer _bubbleTimer;

        private QuotaSnapshot _snapshot;
        private bool _stale;
        private bool _allowClose;
        private bool _resetRefreshTriggered;
        private string _currentGif;
        private string _lastStatus = "正在连接 Codex…";
        private readonly Random _random = new Random();
        private PetAction _petAction = PetAction.Working;
        private DateTime _petActionUntilUtc = DateTime.MaxValue;
        private DateTime _nextIdleActionUtc;
        private Point _dragCursorStart;
        private Point _dragFormStart;
        private bool _dragging;
        private bool _dragCandidate;
        private DateTime _bubbleCollapseAtUtc = DateTime.MaxValue;
        private DateTime _bubbleHoldUntilUtc = DateTime.MinValue;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr window, int index);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int SetWindowLong(IntPtr window, int index, int value);

        public PetForm()
        {
            Text = "Codex 额度桌宠";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            TopMost = true;
            BackColor = TransparencyColor;
            TransparencyKey = TransparencyColor;
            ClientSize = new Size(304, 338);
            AutoScaleMode = AutoScaleMode.Dpi;
            DoubleBuffered = true;

            _settings = SettingsStore.Load();
            LoadEmbeddedGifs();

            _petPicture = new PictureBox();
            _petPicture.Location = new Point(32, 82);
            _petPicture.Size = new Size(240, 240);
            _petPicture.SizeMode = PictureBoxSizeMode.Normal;
            _petPicture.BackColor = TransparencyColor;
            _petPicture.Cursor = Cursors.SizeAll;
            Controls.Add(_petPicture);

            _quotaCard = new QuotaCard();
            Controls.Add(_quotaCard);
            _quotaCard.BringToFront();

            SetPet("03.gif");
            ScheduleNextIdleAction();

            _menu = new ContextMenuStrip();
            _menu.Font = new Font("Microsoft YaHei UI", 9.0f);
            _menu.Items.Add("立即刷新", null, delegate { ManualRefresh(); });
            _menu.Items.Add("打开额度页", null, delegate { OpenUsagePage(); });
            _menu.Items.Add(new ToolStripSeparator());
            _clickThroughItem = new ToolStripMenuItem("鼠标穿透");
            _clickThroughItem.CheckOnClick = true;
            _clickThroughItem.Checked = _settings.ClickThrough;
            _clickThroughItem.CheckedChanged += delegate { SetClickThrough(_clickThroughItem.Checked); };
            _menu.Items.Add(_clickThroughItem);
            _menu.Items.Add("重置位置", null, delegate { ResetPosition(); });
            _autoStartItem = new ToolStripMenuItem("开机自启");
            _autoStartItem.CheckOnClick = true;
            _autoStartItem.Checked = SettingsStore.IsAutoStartEnabled();
            _autoStartItem.CheckedChanged += AutoStartChanged;
            _menu.Items.Add(_autoStartItem);
            _menu.Items.Add(new ToolStripSeparator());
            _visibilityItem = new ToolStripMenuItem("隐藏桌宠");
            _visibilityItem.Click += delegate { ToggleVisibility(); };
            _menu.Items.Add(_visibilityItem);
            _menu.Items.Add("退出", null, delegate { ExitApplication(); });

            ContextMenuStrip = _menu;
            _petPicture.ContextMenuStrip = _menu;
            _quotaCard.ContextMenuStrip = _menu;

            _trayIcon = new NotifyIcon();
            _trayIcon.Text = "Codex 额度桌宠";
            _trayIcon.Icon = SystemIcons.Application;
            _trayIcon.ContextMenuStrip = _menu;
            _trayIcon.Visible = true;
            _trayIcon.DoubleClick += delegate { ToggleVisibility(); };

            _toolTip = new ToolTip();
            _toolTip.SetToolTip(_petPicture, "悬停展开额度对白；拖动可移动，双击打开额度页");
            _toolTip.SetToolTip(_quotaCard, "悬停展开；离开后自动收起，每分钟刷新额度");

            AttachMouseBehavior(this);
            AttachMouseBehavior(_petPicture);
            AttachMouseBehavior(_quotaCard);

            _clockTimer = new Timer();
            _clockTimer.Interval = 1000;
            _clockTimer.Tick += ClockTick;
            _clockTimer.Start();

            _bubbleTimer = new Timer();
            _bubbleTimer.Interval = 100;
            _bubbleTimer.Tick += BubbleTimerTick;
            _bubbleTimer.Start();

            _client = new AppServerClient();
            _client.QuotaUpdated += ClientQuotaUpdated;
            _client.StatusChanged += ClientStatusChanged;

            Shown += PetFormShown;
            FormClosing += PetFormClosing;
        }

        private void PetFormShown(object sender, EventArgs args)
        {
            RestorePosition();
            SetClickThrough(_settings.ClickThrough);
            _quotaCard.SetExpanded(false, false);
            StartWorkingAction();
            _client.Start();
        }

        private void LoadEmbeddedGifs()
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            string[] names = { "01.gif", "02.gif", "03.gif", "04.gif", "05.gif", "06.gif" };
            foreach (string name in names)
            {
                string resourceName = "CodexQuotaPet.DisplayAssets." + name;
                Stream source = assembly.GetManifestResourceStream(resourceName);
                if (source == null)
                {
                    throw new InvalidOperationException("缺少嵌入素材：" + name);
                }

                MemoryStream memory = new MemoryStream();
                source.CopyTo(memory);
                source.Dispose();
                memory.Position = 0;
                _imageStreams.Add(memory);
                _images[name] = Image.FromStream(memory, true, true);
            }
        }

        private void SetPet(string name)
        {
            if (_currentGif == name)
            {
                return;
            }

            Image image;
            if (_images.TryGetValue(name, out image))
            {
                _petPicture.Image = image;
                _currentGif = name;
            }
        }

        private void ApplyPetVisual()
        {
            double? remaining = _snapshot == null
                ? (double?)null
                : _snapshot.RemainingPercent;
            SetPet(PetBehavior.ResolveGif(remaining, _stale, _petAction));
        }

        private void StartWorkingAction()
        {
            _petAction = PetAction.Working;
            _petActionUntilUtc = DateTime.MaxValue;
            ApplyPetVisual();
        }

        private void PlayTemporaryAction(PetAction action, int durationMilliseconds)
        {
            if (_petAction == PetAction.Working &&
                _petActionUntilUtc == DateTime.MaxValue)
            {
                ApplyPetVisual();
                return;
            }
            _petAction = action;
            _petActionUntilUtc = DateTime.UtcNow.AddMilliseconds(durationMilliseconds);
            ApplyPetVisual();
        }

        private void ClearPetAction()
        {
            _petAction = PetAction.None;
            _petActionUntilUtc = DateTime.MinValue;
            ApplyPetVisual();
        }

        private void ScheduleNextIdleAction()
        {
            _nextIdleActionUtc = DateTime.UtcNow.AddSeconds(_random.Next(45, 91));
        }

        private void NoteInteraction()
        {
            ScheduleNextIdleAction();
        }

        private void AdvancePetAction()
        {
            DateTime now = DateTime.UtcNow;
            if (_petAction != PetAction.None &&
                _petActionUntilUtc != DateTime.MaxValue &&
                now >= _petActionUntilUtc)
            {
                ClearPetAction();
            }

            if (_petAction == PetAction.None &&
                !_dragging &&
                !_stale &&
                _snapshot != null &&
                _snapshot.RemainingPercent > 0.0 &&
                now >= _nextIdleActionUtc)
            {
                PlayTemporaryAction(PetAction.IdleYawn, 5000);
                ScheduleNextIdleAction();
            }
        }

        private void ClientQuotaUpdated(QuotaSnapshot snapshot)
        {
            RunOnUi(delegate
            {
                _snapshot = snapshot;
                _stale = false;
                _lastStatus = "额度已更新";
                _resetRefreshTriggered = false;
                _quotaCard.SetSnapshot(snapshot, false, "额度已更新");
                _petAction = PetAction.None;
                _petActionUntilUtc = DateTime.MinValue;
                PlayTemporaryAction(PetAction.Happy, 2500);
                ScheduleNextIdleAction();
                UpdateToolTip();
            });
        }

        private void ClientStatusChanged(string message, bool stale)
        {
            RunOnUi(delegate
            {
                _stale = stale;
                _lastStatus = message;
                if (stale)
                {
                    _petAction = PetAction.None;
                    _petActionUntilUtc = DateTime.MinValue;
                }
                else if (_snapshot == null)
                {
                    _petAction = PetAction.Working;
                    _petActionUntilUtc = DateTime.MaxValue;
                }
                if (stale)
                {
                    _quotaCard.SetSnapshot(_snapshot, true, message);
                }
                else if (_snapshot == null)
                {
                    _quotaCard.SetWorking(null, message);
                }
                else
                {
                    _quotaCard.SetSnapshot(_snapshot, false, message);
                }
                ApplyPetVisual();
                UpdateToolTip();
            });
        }

        private void RunOnUi(Action action)
        {
            if (IsDisposed)
            {
                return;
            }
            if (InvokeRequired)
            {
                try
                {
                    BeginInvoke(action);
                }
                catch (InvalidOperationException)
                {
                }
            }
            else
            {
                action();
            }
        }

        private void ClockTick(object sender, EventArgs args)
        {
            _quotaCard.RefreshClock();
            AdvancePetAction();
            if (_snapshot != null &&
                !_snapshot.IsUnlimited &&
                _snapshot.ResetAtUtc <= DateTime.UtcNow &&
                !_resetRefreshTriggered)
            {
                _resetRefreshTriggered = true;
                StartWorkingAction();
                _quotaCard.SetWorking(_snapshot, "正在刷新额度…");
                _client.Refresh();
            }
        }

        private void BubbleTimerTick(object sender, EventArgs args)
        {
            AdvanceBubbleVisibility(DateTime.UtcNow, IsPointerWithinForm());
        }

        private void ExpandBubble()
        {
            if (_settings.ClickThrough)
            {
                return;
            }

            _bubbleCollapseAtUtc = DateTime.MaxValue;
            _quotaCard.SetExpanded(true, true);
        }

        private void ScheduleBubbleCollapse()
        {
            _bubbleCollapseAtUtc = DateTime.UtcNow.AddSeconds(2);
        }

        private void HoldBubbleAfterClick()
        {
            if (_settings.ClickThrough)
            {
                return;
            }

            DateTime now = DateTime.UtcNow;
            _bubbleHoldUntilUtc = now.AddSeconds(5);
            _bubbleCollapseAtUtc = now.AddSeconds(2);
            _quotaCard.SetExpanded(true, true);
        }

        private void AdvanceBubbleVisibility(DateTime nowUtc, bool pointerInside)
        {
            if (_settings.ClickThrough)
            {
                _quotaCard.SetExpanded(false, true);
                return;
            }

            if (_dragging || pointerInside)
            {
                return;
            }

            if (nowUtc >= _bubbleCollapseAtUtc &&
                nowUtc >= _bubbleHoldUntilUtc)
            {
                _quotaCard.SetExpanded(false, true);
            }
        }

        private bool IsPointerWithinForm()
        {
            if (!Visible || !IsHandleCreated)
            {
                return false;
            }

            return RectangleToScreen(ClientRectangle).Contains(Cursor.Position);
        }

        private void ManualRefresh()
        {
            _lastStatus = "正在刷新额度…";
            NoteInteraction();
            StartWorkingAction();
            _quotaCard.SetWorking(_snapshot, _lastStatus);
            _client.Refresh();
        }

        private void AttachMouseBehavior(Control control)
        {
            control.MouseDown += DragMouseDown;
            control.MouseMove += DragMouseMove;
            control.MouseUp += DragMouseUp;
            control.MouseDoubleClick += DragMouseDoubleClick;
            control.MouseEnter += PetMouseEnter;
            control.MouseLeave += PetMouseLeave;
        }

        private void PetMouseEnter(object sender, EventArgs args)
        {
            NoteInteraction();
            ExpandBubble();
            if (!_dragging)
            {
                PlayTemporaryAction(PetAction.Attention, 1400);
            }
        }

        private void PetMouseLeave(object sender, EventArgs args)
        {
            ScheduleBubbleCollapse();
        }

        private void DragMouseDown(object sender, MouseEventArgs args)
        {
            if (args.Button != MouseButtons.Left)
            {
                return;
            }
            _dragCursorStart = Cursor.Position;
            _dragFormStart = Location;
            _dragCandidate = true;
            _dragging = false;
            NoteInteraction();
            ExpandBubble();
            PlayTemporaryAction(PetAction.Attention, 3000);
        }

        private void DragMouseMove(object sender, MouseEventArgs args)
        {
            if (!_dragCandidate || (Control.MouseButtons & MouseButtons.Left) == 0)
            {
                return;
            }

            Point current = Cursor.Position;
            int deltaX = current.X - _dragCursorStart.X;
            int deltaY = current.Y - _dragCursorStart.Y;
            if (!_dragging && Math.Abs(deltaX) + Math.Abs(deltaY) < 5)
            {
                return;
            }

            if (!_dragging)
            {
                _dragging = true;
                PlayTemporaryAction(PetAction.Attention, 15000);
            }
            Location = new Point(_dragFormStart.X + deltaX, _dragFormStart.Y + deltaY);
        }

        private void DragMouseUp(object sender, MouseEventArgs args)
        {
            if (args.Button != MouseButtons.Left)
            {
                return;
            }
            bool wasDragging = _dragging;
            if (wasDragging)
            {
                ClampToVisibleArea();
                SavePosition();
                PlayTemporaryAction(PetAction.Happy, 1800);
                ScheduleBubbleCollapse();
            }
            else
            {
                PlayTemporaryAction(PetAction.Happy, 1200);
                HoldBubbleAfterClick();
            }
            _dragCandidate = false;
            _dragging = false;
            NoteInteraction();
        }

        private void DragMouseDoubleClick(object sender, MouseEventArgs args)
        {
            if (args.Button == MouseButtons.Left && !_dragging)
            {
                NoteInteraction();
                HoldBubbleAfterClick();
                PlayTemporaryAction(PetAction.Attention, 2000);
                OpenUsagePage();
            }
        }

        private static void OpenUsagePage()
        {
            try
            {
                Process.Start(new ProcessStartInfo(
                    "https://chatgpt.com/codex/settings/usage")
                {
                    UseShellExecute = true
                });
            }
            catch (Exception)
            {
            }
        }

        private void AutoStartChanged(object sender, EventArgs args)
        {
            try
            {
                SettingsStore.SetAutoStart(_autoStartItem.Checked);
            }
            catch (Exception exception)
            {
                _autoStartItem.CheckedChanged -= AutoStartChanged;
                _autoStartItem.Checked = !_autoStartItem.Checked;
                _autoStartItem.CheckedChanged += AutoStartChanged;
                MessageBox.Show(
                    exception.Message,
                    "Codex 额度桌宠",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void SetClickThrough(bool enabled)
        {
            _settings.ClickThrough = enabled;
            _clickThroughItem.Checked = enabled;
            if (IsHandleCreated)
            {
                int style = GetWindowLong(Handle, GwlExStyle);
                if (enabled)
                {
                    style |= WsExTransparent;
                }
                else
                {
                    style &= ~WsExTransparent;
                }
                SetWindowLong(Handle, GwlExStyle, style);
            }
            if (enabled)
            {
                _bubbleCollapseAtUtc = DateTime.MinValue;
                _bubbleHoldUntilUtc = DateTime.MinValue;
                _quotaCard.SetExpanded(false, true);
            }
            SettingsStore.Save(_settings);
        }

        private void ToggleVisibility()
        {
            if (Visible)
            {
                Hide();
                _visibilityItem.Text = "显示桌宠";
            }
            else
            {
                Show();
                TopMost = true;
                _visibilityItem.Text = "隐藏桌宠";
            }
        }

        private void ResetPosition()
        {
            _settings.HasPosition = false;
            MoveToDefaultPosition(Screen.PrimaryScreen);
            SavePosition();
        }

        private void RestorePosition()
        {
            Screen target = FindSavedScreen();
            if (_settings.HasPosition)
            {
                Location = new Point(_settings.X, _settings.Y);
                ClampToVisibleArea();
            }
            else
            {
                MoveToDefaultPosition(target);
            }
        }

        private Screen FindSavedScreen()
        {
            if (!String.IsNullOrWhiteSpace(_settings.Monitor))
            {
                foreach (Screen screen in Screen.AllScreens)
                {
                    if (String.Equals(
                        screen.DeviceName,
                        _settings.Monitor,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        return screen;
                    }
                }
            }
            return Screen.PrimaryScreen;
        }

        private void MoveToDefaultPosition(Screen screen)
        {
            Rectangle area = (screen ?? Screen.PrimaryScreen).WorkingArea;
            Location = new Point(area.Right - Width - 24, area.Bottom - Height - 24);
        }

        private void ClampToVisibleArea()
        {
            Screen screen = Screen.FromRectangle(new Rectangle(Location, Size));
            Rectangle area = screen.WorkingArea;
            int x = Math.Max(area.Left, Math.Min(Left, area.Right - Width));
            int y = Math.Max(area.Top, Math.Min(Top, area.Bottom - Height));
            Location = new Point(x, y);
        }

        private void SavePosition()
        {
            Screen screen = Screen.FromControl(this);
            _settings.HasPosition = true;
            _settings.X = Left;
            _settings.Y = Top;
            _settings.Monitor = screen.DeviceName;
            SettingsStore.Save(_settings);
        }

        private void UpdateToolTip()
        {
            string text = BuildHoverText(_snapshot, _stale);
            _toolTip.SetToolTip(_petPicture, text);
            _toolTip.SetToolTip(_quotaCard, text);
            _trayIcon.Text = BuildTrayText(_snapshot, _stale);
        }

        internal static string BuildHoverText(QuotaSnapshot snapshot, bool stale)
        {
            string text = "悬停展开额度对白；拖动可移动，双击打开额度页";
            if (snapshot != null)
            {
                text += "\n当前显示：" + CurrentWindowName(snapshot);
                if (stale)
                {
                    text += " · 等待更新";
                }
                text += "\n上次更新：" +
                    snapshot.UpdatedAtUtc.ToLocalTime().ToString("HH:mm:ss");
            }
            else if (stale)
            {
                text += "\n等待更新";
            }
            return text;
        }

        internal static string BuildTrayText(QuotaSnapshot snapshot, bool stale)
        {
            string text = "Codex 额度桌宠";
            if (snapshot != null)
            {
                text += " · " + CurrentWindowName(snapshot);
            }
            if (stale)
            {
                text += " · 等待更新";
            }
            return text;
        }

        private static string CurrentWindowName(QuotaSnapshot snapshot)
        {
            if (snapshot == null)
            {
                return "额度";
            }
            if (snapshot.IsUnlimited)
            {
                return "无限";
            }
            if (!String.IsNullOrWhiteSpace(snapshot.WindowDisplayName))
            {
                return snapshot.WindowDisplayName;
            }
            return QuotaWindowFormatter.Format(snapshot.WindowDurationMins);
        }

        private void ExitApplication()
        {
            _allowClose = true;
            Close();
        }

        private void PetFormClosing(object sender, FormClosingEventArgs args)
        {
            if (!_allowClose && args.CloseReason == CloseReason.UserClosing)
            {
                args.Cancel = true;
                Hide();
                _visibilityItem.Text = "显示桌宠";
                return;
            }

            SavePosition();
            _clockTimer.Stop();
            _bubbleTimer.Stop();
            _client.Dispose();
            _trayIcon.Visible = false;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                foreach (Image image in _images.Values)
                {
                    image.Dispose();
                }
                foreach (Stream stream in _imageStreams)
                {
                    stream.Dispose();
                }
                _trayIcon.Dispose();
                _toolTip.Dispose();
                _menu.Dispose();
                _clockTimer.Dispose();
                _bubbleTimer.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

using System;
using System.Globalization;

namespace CodexQuotaPet
{
    internal static class ParserTests
    {
        private static int _passed;

        private static void Main()
        {
            MainBucketChoosesShortestWindow();
            MainBucketOutranksShorterOtherBucket();
            MultiBucketIsAuthoritativeOverLegacy();
            InvalidMainFallsBackToOtherBucket();
            MissingMainChoosesGlobalShortestDuration();
            EqualDurationPrefersPrimaryThenStableBucketId();
            LegacySingleBucketChoosesShortestWindow();
            AcceptsArbitraryWindowAndFormatsNames();
            ClampsAbnormalPercentages();
            AcceptsExpiredResetForImmediateRefresh();
            RecognizesExplicitUnlimitedStates();
            RejectsMalformedAndMissingSurfaces();
            Console.WriteLine("PASS: " + _passed + " parser assertions");
        }

        private static void MainBucketChoosesShortestWindow()
        {
            string json = Result(
                "\"rateLimitsByLimitId\":{" +
                "\"codex\":" + Bucket("codex", Window(8, 300, 1788010858), Window(17, 10080, 1788574632)) +
                "}");
            QuotaSnapshot snapshot = ParseOk(json);
            ExpectNear(300.0, snapshot.WindowDurationMins, "main shortest duration");
            ExpectNear(92.0, snapshot.RemainingPercent, "main shortest remaining");
            Expect("5小时额度", snapshot.WindowDisplayName, "five-hour name");
            Expect("codex", snapshot.LimitId, "main limit id");
        }

        private static void MainBucketOutranksShorterOtherBucket()
        {
            string json = Result(
                "\"rateLimitsByLimitId\":{" +
                "\"codex\":" + Bucket("codex", Window(17, 10080, 1788574632), "null") + "," +
                "\"codex_other\":" + Bucket("codex_other", Window(2, 15, 1788010000), "null") +
                "}");
            QuotaSnapshot snapshot = ParseOk(json);
            ExpectNear(10080.0, snapshot.WindowDurationMins, "main bucket priority");
            Expect("周额度", snapshot.WindowDisplayName, "weekly name");
        }

        private static void MultiBucketIsAuthoritativeOverLegacy()
        {
            string json = Result(
                "\"rateLimitsByLimitId\":{" +
                "\"codex\":" + Bucket("codex", Window(22, 10080, 1788574632), "null") +
                "}," +
                "\"rateLimits\":" + Bucket("codex", Window(1, 5, 1788010000), "null"));
            QuotaSnapshot snapshot = ParseOk(json);
            ExpectNear(10080.0, snapshot.WindowDurationMins, "multi-bucket authoritative");
        }

        private static void InvalidMainFallsBackToOtherBucket()
        {
            string malformedWindow = "{\"windowDurationMins\":300,\"resetsAt\":1788010858}";
            string json = Result(
                "\"rateLimitsByLimitId\":{" +
                "\"codex\":" + Bucket("codex", malformedWindow, "null") + "," +
                "\"backup\":" + Bucket("backup", Window(35, 90, 1788010858), "null") +
                "}");
            QuotaSnapshot snapshot = ParseOk(json);
            ExpectNear(90.0, snapshot.WindowDurationMins, "invalid main fallback duration");
            Expect("backup", snapshot.LimitId, "invalid main fallback id");
        }

        private static void MissingMainChoosesGlobalShortestDuration()
        {
            string json = Result(
                "\"rateLimitsByLimitId\":{" +
                "\"long\":" + Bucket("long", Window(99, 60, 1789000000), "null") + "," +
                "\"short\":" + Bucket("short", Window(1, 15, 1787000000), "null") +
                "}");
            QuotaSnapshot snapshot = ParseOk(json);
            ExpectNear(15.0, snapshot.WindowDurationMins, "global shortest duration");
            ExpectNear(99.0, snapshot.RemainingPercent, "duration not percent selection");
            Expect("short", snapshot.LimitId, "duration not reset selection");
        }

        private static void EqualDurationPrefersPrimaryThenStableBucketId()
        {
            string primaryWins = Result(
                "\"rateLimitsByLimitId\":{" +
                "\"a\":" + Bucket("a", "null", Window(1, 60, 1788010858)) + "," +
                "\"z\":" + Bucket("z", Window(2, 60, 1788010858), "null") +
                "}");
            Expect("z", ParseOk(primaryWins).LimitId, "primary tie priority");

            string idWins = Result(
                "\"rateLimitsByLimitId\":{" +
                "\"b\":" + Bucket("b", Window(3, 60, 1788010858), "null") + "," +
                "\"a\":" + Bucket("a", Window(4, 60, 1788010858), "null") +
                "}");
            Expect("a", ParseOk(idWins).LimitId, "stable bucket id tie priority");
        }

        private static void LegacySingleBucketChoosesShortestWindow()
        {
            string json = Result(
                "\"rateLimits\":" +
                Bucket("codex", Window(17, 10080, 1788574632), Window(8, 300, 1788010858)));
            QuotaSnapshot snapshot = ParseOk(json);
            ExpectNear(300.0, snapshot.WindowDurationMins, "legacy shortest window");
            ExpectNear(92.0, snapshot.RemainingPercent, "legacy secondary selected");
        }

        private static void AcceptsArbitraryWindowAndFormatsNames()
        {
            QuotaSnapshot ninety = ParseOk(Result(
                "\"rateLimits\":" + Bucket("codex", Window(12, 90, 1788010858), "null")));
            Expect("90分钟额度", ninety.WindowDisplayName, "arbitrary minute name");

            QuotaSnapshot twoDays = ParseOk(Result(
                "\"rateLimits\":" + Bucket("codex", Window(12, 2880, 1788010858), "null")));
            Expect("2天额度", twoDays.WindowDisplayName, "whole-day name");

            QuotaSnapshot twoHours = ParseOk(Result(
                "\"rateLimits\":" + Bucket("codex", Window(12, 120, 1788010858), "null")));
            Expect("2小时额度", twoHours.WindowDisplayName, "whole-hour name");
        }

        private static void ClampsAbnormalPercentages()
        {
            QuotaSnapshot high = ParseOk(Result(
                "\"rateLimits\":" + Bucket("codex", Window(140, 300, 1788010858), "null")));
            ExpectNear(0.0, high.RemainingPercent, "high percent clamp");

            QuotaSnapshot low = ParseOk(Result(
                "\"rateLimits\":" + Bucket("codex", Window(-4, 300, 1788010858), "null")));
            ExpectNear(100.0, low.RemainingPercent, "low percent clamp");
        }

        private static void AcceptsExpiredResetForImmediateRefresh()
        {
            QuotaSnapshot snapshot = ParseOk(Result(
                "\"rateLimits\":" + Bucket("codex", Window(20, 300, 1), "null")));
            ExpectTrue(snapshot.ResetAtUtc < DateTime.UtcNow, "expired reset preserved");
        }

        private static void RecognizesExplicitUnlimitedStates()
        {
            QuotaSnapshot emptyMulti = ParseOk(Result("\"rateLimitsByLimitId\":{}"));
            ExpectTrue(emptyMulti.IsUnlimited, "empty multi is unlimited");
            Expect("无限", emptyMulti.WindowDisplayName, "unlimited name");

            QuotaSnapshot nullSingle = ParseOk(Result("\"rateLimits\":null"));
            ExpectTrue(nullSingle.IsUnlimited, "null legacy is unlimited");

            QuotaSnapshot nullWindows = ParseOk(Result(
                "\"rateLimits\":" + Bucket("codex", "null", "null")));
            ExpectTrue(nullWindows.IsUnlimited, "explicit null windows are unlimited");

            QuotaSnapshot authoritativeEmpty = ParseOk(Result(
                "\"rateLimitsByLimitId\":{}," +
                "\"rateLimits\":" + Bucket("codex", Window(1, 300, 1788010858), "null")));
            ExpectTrue(authoritativeEmpty.IsUnlimited, "empty multi remains authoritative");
        }

        private static void RejectsMalformedAndMissingSurfaces()
        {
            ParseFail(Result("\"rateLimits\":{}"), "empty legacy bucket is malformed");
            ParseFail(Result(
                "\"rateLimits\":{" +
                "\"primary\":{\"usedPercent\":1,\"windowDurationMins\":300}}"),
                "missing reset is malformed");
            ParseFail(Result("\"rateLimitsByLimitId\":[]"), "multi-bucket wrong type");
            ParseFail("{\"result\":{}}", "missing quota surfaces");
            ParseFail("not-json", "invalid json");
        }

        private static string Result(string body)
        {
            return "{\"id\":1,\"result\":{" + body + "}}";
        }

        private static string Bucket(string id, string primary, string secondary)
        {
            return "{\"limitId\":\"" + id + "\",\"primary\":" + primary +
                   ",\"secondary\":" + secondary + "}";
        }

        private static string Window(double used, double minutes, long reset)
        {
            return "{\"usedPercent\":" + used.ToString(CultureInfo.InvariantCulture) +
                   ",\"windowDurationMins\":" + minutes.ToString(CultureInfo.InvariantCulture) +
                   ",\"resetsAt\":" + reset.ToString(CultureInfo.InvariantCulture) + "}";
        }

        private static QuotaSnapshot ParseOk(string json)
        {
            QuotaSnapshot snapshot;
            string error;
            if (!QuotaParser.TryParse(json, out snapshot, out error))
            {
                throw new Exception("Expected parse success: " + error + "\n" + json);
            }
            return snapshot;
        }

        private static void ParseFail(string json, string name)
        {
            QuotaSnapshot snapshot;
            string error;
            if (QuotaParser.TryParse(json, out snapshot, out error))
            {
                throw new Exception("Expected parse failure: " + name);
            }
            _passed++;
        }

        private static void Expect(string expected, string actual, string name)
        {
            if (!String.Equals(expected, actual, StringComparison.Ordinal))
            {
                throw new Exception(name + ": expected '" + expected + "', actual '" + actual + "'");
            }
            _passed++;
        }

        private static void ExpectNear(double expected, double actual, string name)
        {
            if (Math.Abs(expected - actual) > 0.001)
            {
                throw new Exception(name + ": expected " + expected + ", actual " + actual);
            }
            _passed++;
        }

        private static void ExpectTrue(bool value, string name)
        {
            if (!value)
            {
                throw new Exception(name + ": expected true");
            }
            _passed++;
        }
    }
}

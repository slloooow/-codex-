using System;

namespace CodexQuotaPet
{
    internal enum PetAction
    {
        None,
        Working,
        IdleYawn,
        Attention,
        Happy
    }

    internal static class PetBehavior
    {
        public static string ResolveGif(
            double? remainingPercent,
            bool stale,
            PetAction action)
        {
            if (!remainingPercent.HasValue)
            {
                return stale ? "02.gif" : "03.gif";
            }

            double remaining = Math.Max(0.0, Math.Min(100.0, remainingPercent.Value));

            // Exhaustion and connection failures are important states and must not
            // be hidden by playful hover/click/idle reactions.
            if (remaining <= 0.0)
            {
                return "01.gif";
            }
            if (stale)
            {
                return "02.gif";
            }

            switch (action)
            {
                case PetAction.Working:
                    return "03.gif";
                case PetAction.IdleYawn:
                    return "04.gif";
                case PetAction.Attention:
                    return "05.gif";
                case PetAction.Happy:
                    return "06.gif";
            }

            if (remaining >= 70.0)
            {
                return "06.gif";
            }
            if (remaining >= 40.0)
            {
                return "05.gif";
            }
            if (remaining >= 15.0)
            {
                return "04.gif";
            }
            return "02.gif";
        }
    }
}

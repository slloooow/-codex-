using System;
using System.Reflection;
using System.Windows.Forms;

namespace CodexQuotaPet
{
    internal static class PetInteractionTests
    {
        private const BindingFlags PrivateInstance =
            BindingFlags.Instance | BindingFlags.NonPublic;

        private static int _passed;

        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            PetForm form = new PetForm();
            try
            {
                SetQuota(form, 80.0);
                ExpectGif(form, "06.gif", "successful read");
                ExpectBubble(form, false, "background update stays compact");
                ExpectContains(
                    GetHoverText(form),
                    "当前显示：5小时额度",
                    "five-hour hover label");

                SetQuota(form, 80.0, 10080.0, "周额度");
                ExpectContains(GetHoverText(form), "当前显示：周额度", "weekly hover label");
                ExpectContains(GetTrayText(form), "周额度", "weekly tray label");
                SetQuota(form, 80.0);

                Invoke(form, "PetMouseEnter", null, EventArgs.Empty);
                ExpectGif(form, "05.gif", "hover attention");
                ExpectBubble(form, true, "hover expands bubble");

                SetField(form, "_bubbleCollapseAtUtc", DateTime.UtcNow.AddSeconds(-1));
                SetField(form, "_bubbleHoldUntilUtc", DateTime.UtcNow.AddSeconds(-1));
                Invoke(form, "AdvanceBubbleVisibility", DateTime.UtcNow, false);
                ExpectBubble(form, false, "leave delay eventually collapses");

                Invoke(form, "DragMouseDown", null, new MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0));
                ExpectGif(form, "05.gif", "mouse down attention");
                SetField(form, "_dragging", true);
                SetField(form, "_bubbleCollapseAtUtc", DateTime.UtcNow.AddSeconds(-1));
                Invoke(form, "AdvanceBubbleVisibility", DateTime.UtcNow, false);
                ExpectBubble(form, true, "drag keeps bubble expanded");
                Invoke(form, "DragMouseUp", null, new MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0));
                ExpectGif(form, "06.gif", "click response");

                SetField(form, "_bubbleCollapseAtUtc", DateTime.UtcNow.AddSeconds(-1));
                SetField(form, "_bubbleHoldUntilUtc", DateTime.UtcNow.AddSeconds(-1));
                Invoke(form, "AdvanceBubbleVisibility", DateTime.UtcNow, false);
                Invoke(form, "DragMouseDown", null, new MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0));
                Invoke(form, "DragMouseUp", null, new MouseEventArgs(MouseButtons.Left, 1, 0, 0, 0));
                ExpectBubble(form, true, "click expands bubble");
                SetField(form, "_bubbleCollapseAtUtc", DateTime.UtcNow.AddSeconds(-1));
                Invoke(form, "AdvanceBubbleVisibility", DateTime.UtcNow, false);
                ExpectBubble(form, true, "click hold prevents early collapse");
                SetField(form, "_bubbleHoldUntilUtc", DateTime.UtcNow.AddSeconds(-1));
                Invoke(form, "AdvanceBubbleVisibility", DateTime.UtcNow, false);
                ExpectBubble(form, false, "click hold eventually expires");

                PetSettings settings = (PetSettings)GetField(form, "_settings");
                settings.ClickThrough = true;
                ((QuotaCard)GetField(form, "_quotaCard")).SetExpanded(true, false);
                Invoke(form, "AdvanceBubbleVisibility", DateTime.UtcNow, false);
                ExpectBubble(form, false, "click through forces compact bubble");
                settings.ClickThrough = false;

                Invoke(form, "StartWorkingAction");
                ExpectGif(form, "03.gif", "refresh work");
                Invoke(form, "PetMouseEnter", null, EventArgs.Empty);
                ExpectGif(form, "03.gif", "refresh priority over hover");

                Invoke(form, "ClientStatusChanged", "连接已断开", true);
                ExpectGif(form, "02.gif", "stale connection");

                SetUnlimited(form);
                ExpectGif(form, "06.gif", "unlimited uses happy animation");
                ExpectContains(GetHoverText(form), "当前显示：无限", "unlimited hover label");
                ExpectContains(GetTrayText(form), "无限", "unlimited tray label");
                SetField(form, "_resetRefreshTriggered", false);
                Invoke(form, "ClockTick", null, EventArgs.Empty);
                ExpectFalse(
                    Convert.ToBoolean(GetField(form, "_resetRefreshTriggered")),
                    "unlimited does not trigger reset refresh");
                Invoke(form, "ClientStatusChanged", "连接已断开", true);
                ExpectContains(GetTrayText(form), "等待更新", "stale tray marker");

                SetQuota(form, 0.0);
                ExpectGif(form, "01.gif", "exhausted quota priority");

                SetQuota(form, 60.0);
                SetField(form, "_petAction", PetAction.None);
                SetField(form, "_petActionUntilUtc", DateTime.MinValue);
                SetField(form, "_nextIdleActionUtc", DateTime.UtcNow.AddSeconds(-1));
                Invoke(form, "AdvancePetAction");
                ExpectGif(form, "04.gif", "automatic idle yawn");

                Console.WriteLine("PASS: " + _passed + " pet interaction scenarios");
            }
            finally
            {
                AppServerClient client = (AppServerClient)GetField(form, "_client");
                client.Dispose();
                form.Dispose();
            }
        }

        private static void SetQuota(PetForm form, double remaining)
        {
            SetQuota(form, remaining, 300.0, "5小时额度");
        }

        private static void SetQuota(
            PetForm form,
            double remaining,
            double windowMinutes,
            string windowName)
        {
            Invoke(
                form,
                "ClientQuotaUpdated",
                new QuotaSnapshot
                {
                    UsedPercent = 100.0 - remaining,
                    RemainingPercent = remaining,
                    ResetAtUtc = DateTime.UtcNow.AddHours(4),
                    UpdatedAtUtc = DateTime.UtcNow,
                    WindowDurationMins = windowMinutes,
                    WindowDisplayName = windowName,
                    LimitId = "codex"
                });
        }

        private static void SetUnlimited(PetForm form)
        {
            Invoke(
                form,
                "ClientQuotaUpdated",
                new QuotaSnapshot
                {
                    UsedPercent = 0.0,
                    RemainingPercent = 100.0,
                    ResetAtUtc = DateTime.MaxValue,
                    UpdatedAtUtc = DateTime.UtcNow,
                    WindowDisplayName = "无限",
                    IsUnlimited = true
                });
        }

        private static string GetHoverText(PetForm form)
        {
            ToolTip tip = (ToolTip)GetField(form, "_toolTip");
            QuotaCard card = (QuotaCard)GetField(form, "_quotaCard");
            return tip.GetToolTip(card);
        }

        private static string GetTrayText(PetForm form)
        {
            NotifyIcon tray = (NotifyIcon)GetField(form, "_trayIcon");
            return tray.Text;
        }

        private static void ExpectGif(PetForm form, string expected, string name)
        {
            string actual = Convert.ToString(GetField(form, "_currentGif"));
            if (!String.Equals(expected, actual, StringComparison.Ordinal))
            {
                throw new Exception(name + ": expected " + expected + ", actual " + actual);
            }
            _passed++;
        }

        private static void ExpectBubble(PetForm form, bool expected, string name)
        {
            QuotaCard card = (QuotaCard)GetField(form, "_quotaCard");
            if (card.IsExpanded != expected)
            {
                throw new Exception(
                    name + ": expected expanded=" + expected +
                    ", actual=" + card.IsExpanded);
            }
            _passed++;
        }

        private static void ExpectContains(string actual, string expectedPart, string name)
        {
            if (actual == null || actual.IndexOf(expectedPart, StringComparison.Ordinal) < 0)
            {
                throw new Exception(name + ": expected to contain '" + expectedPart +
                    "', actual '" + actual + "'");
            }
            _passed++;
        }

        private static void ExpectFalse(bool actual, string name)
        {
            if (actual)
            {
                throw new Exception(name + ": expected false");
            }
            _passed++;
        }

        private static object Invoke(PetForm form, string method, params object[] args)
        {
            MethodInfo info = typeof(PetForm).GetMethod(method, PrivateInstance);
            if (info == null)
            {
                throw new MissingMethodException(typeof(PetForm).FullName, method);
            }
            return info.Invoke(form, args);
        }

        private static object GetField(PetForm form, string name)
        {
            FieldInfo field = typeof(PetForm).GetField(name, PrivateInstance);
            if (field == null)
            {
                throw new MissingFieldException(typeof(PetForm).FullName, name);
            }
            return field.GetValue(form);
        }

        private static void SetField(PetForm form, string name, object value)
        {
            FieldInfo field = typeof(PetForm).GetField(name, PrivateInstance);
            if (field == null)
            {
                throw new MissingFieldException(typeof(PetForm).FullName, name);
            }
            field.SetValue(form, value);
        }
    }
}

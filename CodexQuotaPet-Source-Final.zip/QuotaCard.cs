using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace CodexQuotaPet
{
    internal sealed class QuotaCard : Control
    {
        public static readonly Rectangle CompactBounds = new Rectangle(106, 38, 92, 54);
        public static readonly Rectangle ExpandedBounds = new Rectangle(9, 0, 286, 100);

        private const int AnimationDurationMilliseconds = 160;

        private readonly Font _dialogueFont;
        private readonly Font _smallDialogueFont;
        private readonly Font _tinyDialogueFont;
        private readonly Font _detailFont;
        private readonly Font _compactFont;
        private readonly Timer _animationTimer;

        private QuotaSnapshot _snapshot;
        private string _status = "正在连接 Codex…";
        private bool _stale;
        private bool _loading = true;
        private bool _targetExpanded;
        private Rectangle _animationFrom;
        private Rectangle _animationTo;
        private DateTime _animationStartedUtc;

        public QuotaCard()
        {
            SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw |
                ControlStyles.SupportsTransparentBackColor |
                ControlStyles.UserPaint,
                true);
            Bounds = CompactBounds;
            BackColor = PetForm.TransparencyColor;
            Cursor = Cursors.SizeAll;

            _dialogueFont = new Font("Microsoft YaHei UI", 13.0f, FontStyle.Bold, GraphicsUnit.Point);
            _smallDialogueFont = new Font("Microsoft YaHei UI", 11.5f, FontStyle.Bold, GraphicsUnit.Point);
            _tinyDialogueFont = new Font("Microsoft YaHei UI", 9.0f, FontStyle.Bold, GraphicsUnit.Point);
            _detailFont = new Font("Microsoft YaHei UI", 9.0f, FontStyle.Regular, GraphicsUnit.Point);
            _compactFont = new Font("Microsoft YaHei UI", 14.0f, FontStyle.Bold, GraphicsUnit.Point);

            _animationTimer = new Timer();
            _animationTimer.Interval = 16;
            _animationTimer.Tick += AnimationTick;
        }

        public bool IsExpanded
        {
            get { return _targetExpanded; }
        }

        public void SetSnapshot(QuotaSnapshot snapshot, bool stale, string status)
        {
            _snapshot = snapshot;
            _stale = stale;
            _loading = snapshot == null && !stale;
            _status = status ?? String.Empty;
            Invalidate();
        }

        public void SetWorking(QuotaSnapshot snapshot, string status)
        {
            _snapshot = snapshot;
            _stale = false;
            _loading = true;
            _status = status ?? String.Empty;
            Invalidate();
        }

        public void SetStatus(string status, bool stale)
        {
            _status = status ?? String.Empty;
            _stale = stale;
            _loading = !stale;
            Invalidate();
        }

        public void RefreshClock()
        {
            Invalidate();
        }

        public void SetExpanded(bool expanded, bool animate)
        {
            Rectangle target = expanded ? ExpandedBounds : CompactBounds;
            if (animate && _targetExpanded == expanded && _animationTimer.Enabled)
            {
                return;
            }
            _targetExpanded = expanded;

            if (!animate)
            {
                _animationTimer.Stop();
                Bounds = target;
                Invalidate();
                return;
            }

            if (Bounds == target)
            {
                _animationTimer.Stop();
                Invalidate();
                return;
            }

            _animationFrom = Bounds;
            _animationTo = target;
            _animationStartedUtc = DateTime.UtcNow;
            _animationTimer.Start();
        }

        private void AnimationTick(object sender, EventArgs args)
        {
            double elapsed = (DateTime.UtcNow - _animationStartedUtc).TotalMilliseconds;
            double progress = Math.Max(0.0, Math.Min(1.0, elapsed / AnimationDurationMilliseconds));
            double eased = 1.0 - Math.Pow(1.0 - progress, 3.0);
            Bounds = Interpolate(_animationFrom, _animationTo, eased);
            Invalidate();

            if (progress >= 1.0)
            {
                _animationTimer.Stop();
                Bounds = _animationTo;
            }
        }

        private static Rectangle Interpolate(Rectangle from, Rectangle to, double amount)
        {
            return new Rectangle(
                Interpolate(from.X, to.X, amount),
                Interpolate(from.Y, to.Y, amount),
                Interpolate(from.Width, to.Width, amount),
                Interpolate(from.Height, to.Height, amount));
        }

        private static int Interpolate(int from, int to, double amount)
        {
            return (int)Math.Round(from + ((to - from) * amount));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics graphics = e.Graphics;
            graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

            using (GraphicsPath path = CloudBubblePath())
            using (SolidBrush fill = new SolidBrush(Color.FromArgb(255, 252, 255)))
            using (Pen undercoat = new Pen(Color.FromArgb(45, 50, 103), 4.2f))
            using (Pen outline = new Pen(Color.FromArgb(45, 50, 103), 2.4f))
            {
                RectangleF[] dots = ThoughtDots();
                graphics.SmoothingMode = SmoothingMode.None;
                undercoat.LineJoin = LineJoin.Round;
                graphics.DrawPath(undercoat, path);
                foreach (RectangleF dot in dots)
                {
                    graphics.DrawEllipse(undercoat, dot);
                }

                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                outline.LineJoin = LineJoin.Round;
                graphics.FillPath(fill, path);
                graphics.DrawPath(outline, path);
                foreach (RectangleF dot in dots)
                {
                    graphics.FillEllipse(fill, dot);
                    graphics.DrawEllipse(outline, dot);
                }
            }

            QuotaSpeechContent content = QuotaSpeech.Build(
                _snapshot,
                _stale,
                _loading,
                _status,
                DateTime.UtcNow);

            if (Width < 170)
            {
                DrawCompact(graphics, content);
            }
            else
            {
                DrawExpanded(graphics, content);
            }
        }

        private void DrawCompact(Graphics graphics, QuotaSpeechContent content)
        {
            Color color = content.CompactText.IndexOf("!", StringComparison.Ordinal) >= 0
                ? Color.FromArgb(221, 75, 110)
                : Color.FromArgb(227, 79, 145);
            RectangleF textArea = new RectangleF(8.0f, 4.0f, Width - 16.0f, Height - 24.0f);
            using (SolidBrush brush = new SolidBrush(color))
            using (StringFormat format = new StringFormat())
            {
                format.Alignment = StringAlignment.Center;
                format.LineAlignment = StringAlignment.Center;
                graphics.DrawString(content.CompactText, _compactFont, brush, textArea, format);
            }
        }

        private void DrawExpanded(Graphics graphics, QuotaSpeechContent content)
        {
            Color navy = Color.FromArgb(45, 50, 103);
            Color pink = Color.FromArgb(227, 79, 145);
            Color muted = Color.FromArgb(91, 86, 119);

            using (SolidBrush detailBrush = new SolidBrush(muted))
            {
                graphics.DrawString(content.Detail, _detailFont, detailBrush, new PointF(36.0f, 52.0f));
            }

            DrawComicMarks(graphics, pink);
            DrawDialogue(graphics, content, navy, pink);
        }

        private void DrawDialogue(
            Graphics graphics,
            QuotaSpeechContent content,
            Color navy,
            Color pink)
        {
            Font font = _dialogueFont;
            float maximum = Width - 60.0f;
            if (MeasureDialogue(graphics, content, font) > maximum)
            {
                font = _smallDialogueFont;
                if (MeasureDialogue(graphics, content, font) > maximum)
                {
                    font = _tinyDialogueFont;
                }
            }

            float x = 30.0f;
            const float y = 22.0f;
            using (StringFormat format = (StringFormat)StringFormat.GenericTypographic.Clone())
            using (SolidBrush navyBrush = new SolidBrush(navy))
            using (SolidBrush pinkBrush = new SolidBrush(pink))
            {
                format.FormatFlags |= StringFormatFlags.MeasureTrailingSpaces;
                graphics.DrawString(content.Prefix, font, navyBrush, new PointF(x, y), format);
                x += graphics.MeasureString(content.Prefix, font, Int32.MaxValue, format).Width;
                graphics.DrawString(content.Highlight, font, pinkBrush, new PointF(x, y), format);
                x += graphics.MeasureString(content.Highlight, font, Int32.MaxValue, format).Width;
                graphics.DrawString(content.Suffix, font, navyBrush, new PointF(x, y), format);
            }
        }

        private static float MeasureDialogue(
            Graphics graphics,
            QuotaSpeechContent content,
            Font font)
        {
            using (StringFormat format = (StringFormat)StringFormat.GenericTypographic.Clone())
            {
                format.FormatFlags |= StringFormatFlags.MeasureTrailingSpaces;
                return graphics.MeasureString(content.Dialogue, font, Int32.MaxValue, format).Width;
            }
        }

        private void DrawComicMarks(Graphics graphics, Color pink)
        {
            using (Pen pen = new Pen(pink, 1.8f))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;
                graphics.DrawLine(pen, Width - 46.0f, 13.0f, Width - 40.0f, 10.0f);
                graphics.DrawLine(pen, Width - 43.0f, 19.0f, Width - 35.0f, 19.0f);
                graphics.DrawLine(pen, Width - 47.0f, 24.0f, Width - 41.0f, 27.0f);
            }
        }

        private GraphicsPath CloudBubblePath()
        {
            const float inset = 3.0f;
            float left = inset;
            float top = inset;
            float cloudWidth = Width - (inset * 2.0f);
            float cloudHeight = Height - 16.0f;
            GraphicsPath path = new GraphicsPath();
            if (Width < 170)
            {
                AddCompactCloud(path, left, top, cloudWidth, cloudHeight);
            }
            else
            {
                AddExpandedCloud(path, left, top, cloudWidth, cloudHeight);
            }
            path.CloseFigure();
            return path;
        }

        private static void AddExpandedCloud(
            GraphicsPath path,
            float x,
            float y,
            float width,
            float height)
        {
            path.StartFigure();
            path.AddBezier(P(x, y, width, height, 0.03f, 0.50f), P(x, y, width, height, -0.02f, 0.42f), P(x, y, width, height, 0.01f, 0.22f), P(x, y, width, height, 0.11f, 0.20f));
            path.AddBezier(P(x, y, width, height, 0.11f, 0.20f), P(x, y, width, height, 0.12f, 0.04f), P(x, y, width, height, 0.24f, 0.01f), P(x, y, width, height, 0.27f, 0.11f));
            path.AddBezier(P(x, y, width, height, 0.27f, 0.11f), P(x, y, width, height, 0.33f, -0.01f), P(x, y, width, height, 0.42f, -0.01f), P(x, y, width, height, 0.44f, 0.09f));
            path.AddBezier(P(x, y, width, height, 0.44f, 0.09f), P(x, y, width, height, 0.49f, -0.02f), P(x, y, width, height, 0.58f, -0.02f), P(x, y, width, height, 0.61f, 0.09f));
            path.AddBezier(P(x, y, width, height, 0.61f, 0.09f), P(x, y, width, height, 0.68f, -0.01f), P(x, y, width, height, 0.78f, 0.02f), P(x, y, width, height, 0.79f, 0.14f));
            path.AddBezier(P(x, y, width, height, 0.79f, 0.14f), P(x, y, width, height, 0.88f, 0.06f), P(x, y, width, height, 0.97f, 0.14f), P(x, y, width, height, 0.94f, 0.27f));
            path.AddBezier(P(x, y, width, height, 0.94f, 0.27f), P(x, y, width, height, 1.02f, 0.31f), P(x, y, width, height, 1.01f, 0.55f), P(x, y, width, height, 0.97f, 0.59f));
            path.AddBezier(P(x, y, width, height, 0.97f, 0.59f), P(x, y, width, height, 1.00f, 0.75f), P(x, y, width, height, 0.88f, 0.84f), P(x, y, width, height, 0.86f, 0.78f));
            path.AddBezier(P(x, y, width, height, 0.86f, 0.78f), P(x, y, width, height, 0.79f, 0.91f), P(x, y, width, height, 0.69f, 0.91f), P(x, y, width, height, 0.66f, 0.84f));
            path.AddBezier(P(x, y, width, height, 0.66f, 0.84f), P(x, y, width, height, 0.59f, 0.94f), P(x, y, width, height, 0.50f, 0.94f), P(x, y, width, height, 0.47f, 0.85f));
            path.AddBezier(P(x, y, width, height, 0.47f, 0.85f), P(x, y, width, height, 0.39f, 0.95f), P(x, y, width, height, 0.28f, 0.92f), P(x, y, width, height, 0.26f, 0.82f));
            path.AddBezier(P(x, y, width, height, 0.26f, 0.82f), P(x, y, width, height, 0.17f, 0.91f), P(x, y, width, height, 0.06f, 0.80f), P(x, y, width, height, 0.08f, 0.69f));
            path.AddBezier(P(x, y, width, height, 0.08f, 0.69f), P(x, y, width, height, -0.01f, 0.69f), P(x, y, width, height, -0.02f, 0.55f), P(x, y, width, height, 0.03f, 0.50f));
        }

        private static void AddCompactCloud(
            GraphicsPath path,
            float x,
            float y,
            float width,
            float height)
        {
            path.StartFigure();
            path.AddBezier(P(x, y, width, height, 0.08f, 0.53f), P(x, y, width, height, -0.02f, 0.45f), P(x, y, width, height, 0.03f, 0.25f), P(x, y, width, height, 0.22f, 0.26f));
            path.AddBezier(P(x, y, width, height, 0.22f, 0.26f), P(x, y, width, height, 0.21f, 0.05f), P(x, y, width, height, 0.42f, 0.02f), P(x, y, width, height, 0.46f, 0.18f));
            path.AddBezier(P(x, y, width, height, 0.46f, 0.18f), P(x, y, width, height, 0.56f, 0.01f), P(x, y, width, height, 0.76f, 0.07f), P(x, y, width, height, 0.73f, 0.25f));
            path.AddBezier(P(x, y, width, height, 0.73f, 0.25f), P(x, y, width, height, 0.95f, 0.18f), P(x, y, width, height, 1.02f, 0.45f), P(x, y, width, height, 0.89f, 0.57f));
            path.AddBezier(P(x, y, width, height, 0.89f, 0.57f), P(x, y, width, height, 0.92f, 0.78f), P(x, y, width, height, 0.69f, 0.85f), P(x, y, width, height, 0.62f, 0.72f));
            path.AddBezier(P(x, y, width, height, 0.62f, 0.72f), P(x, y, width, height, 0.50f, 0.90f), P(x, y, width, height, 0.32f, 0.87f), P(x, y, width, height, 0.29f, 0.72f));
            path.AddBezier(P(x, y, width, height, 0.29f, 0.72f), P(x, y, width, height, 0.18f, 0.84f), P(x, y, width, height, 0.04f, 0.73f), P(x, y, width, height, 0.08f, 0.53f));
        }

        private RectangleF[] ThoughtDots()
        {
            if (Width < 170)
            {
                return new[]
                {
                    new RectangleF(55.0f, 34.0f, 10.0f, 8.0f),
                    new RectangleF(48.0f, 45.0f, 6.0f, 5.0f)
                };
            }

            return new[]
            {
                new RectangleF(180.0f, 75.0f, 14.0f, 11.0f),
                new RectangleF(172.0f, 86.0f, 9.0f, 7.0f),
                new RectangleF(166.0f, 94.0f, 5.0f, 4.0f)
            };
        }

        private static PointF P(
            float x,
            float y,
            float width,
            float height,
            float normalizedX,
            float normalizedY)
        {
            return new PointF(
                x + (width * normalizedX),
                y + (height * normalizedY));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _animationTimer.Dispose();
                _dialogueFont.Dispose();
                _smallDialogueFont.Dispose();
                _tinyDialogueFont.Dispose();
                _detailFont.Dispose();
                _compactFont.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

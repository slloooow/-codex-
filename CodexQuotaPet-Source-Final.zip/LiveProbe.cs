using System;
using System.Threading;

namespace CodexQuotaPet
{
    internal static class LiveProbe
    {
        private static int Main()
        {
            using (ManualResetEvent completed = new ManualResetEvent(false))
            using (AppServerClient client = new AppServerClient())
            {
                QuotaSnapshot received = null;
                string lastStatus = null;
                client.QuotaUpdated += delegate(QuotaSnapshot snapshot)
                {
                    received = snapshot;
                    completed.Set();
                };
                client.StatusChanged += delegate(string status, bool stale)
                {
                    lastStatus = status;
                };
                client.Start();
                if (!completed.WaitOne(TimeSpan.FromSeconds(25)))
                {
                    Console.Error.WriteLine("FAIL: " + (lastStatus ?? "timeout"));
                    return 1;
                }

                Console.WriteLine(
                    "remainingPercent={0:0.##};usedPercent={1:0.##};" +
                    "resetAtUtc={2:o};windowDurationMins={3:0.##};" +
                    "windowName={4};limitId={5};isUnlimited={6}",
                    received.RemainingPercent,
                    received.UsedPercent,
                    received.ResetAtUtc,
                    received.WindowDurationMins,
                    received.WindowDisplayName,
                    received.LimitId ?? String.Empty,
                    received.IsUnlimited);
                return 0;
            }
        }
    }
}

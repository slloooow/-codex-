using System;

namespace CodexQuotaPet
{
    internal static class PetBehaviorTests
    {
        private static int _passed;

        private static void Main()
        {
            Expect("03.gif", null, false, PetAction.None, "initial loading");
            Expect("02.gif", null, true, PetAction.None, "unavailable");
            Expect("01.gif", 0.0, false, PetAction.Happy, "zero overrides reaction");
            Expect("02.gif", 65.0, true, PetAction.Happy, "stale overrides reaction");
            Expect("03.gif", 65.0, false, PetAction.Working, "refreshing");
            Expect("04.gif", 65.0, false, PetAction.IdleYawn, "idle yawn");
            Expect("05.gif", 65.0, false, PetAction.Attention, "attention");
            Expect("06.gif", 12.0, false, PetAction.Happy, "success reaction");
            Expect("06.gif", 70.0, false, PetAction.None, "high quota");
            Expect("05.gif", 40.0, false, PetAction.None, "medium quota");
            Expect("04.gif", 15.0, false, PetAction.None, "low quota");
            Expect("02.gif", 1.0, false, PetAction.None, "critical quota");
            Expect("01.gif", -20.0, false, PetAction.None, "low clamp");
            Expect("06.gif", 120.0, false, PetAction.None, "high clamp");
            Console.WriteLine("PASS: " + _passed + " pet behavior scenarios");
        }

        private static void Expect(
            string expected,
            double? remaining,
            bool stale,
            PetAction action,
            string name)
        {
            string actual = PetBehavior.ResolveGif(remaining, stale, action);
            if (!String.Equals(expected, actual, StringComparison.Ordinal))
            {
                throw new Exception(name + ": expected " + expected + ", actual " + actual);
            }
            _passed++;
        }
    }
}

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace CodexQuotaPet
{
    internal static class VisualProbe
    {
        private const int PanelWidth = 304;
        private const int PanelHeight = 338;
        private const int CaptionHeight = 30;

        private sealed class Scenario
        {
            public string Name;
            public string Gif;
            public QuotaSnapshot Snapshot;
            public bool Stale;
            public bool Loading;
            public bool Expanded;
            public string Status;
        }

        [STAThread]
        private static int Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.Error.WriteLine("Usage: VisualProbe <output.png>");
                return 2;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            DateTime now = DateTime.UtcNow;
            Scenario[] scenarios =
            {
                new Scenario
                {
                    Name = "收起 · 实时百分比",
                    Gif = "06.gif",
                    Snapshot = Snapshot(64.0, now),
                    Expanded = false,
                    Status = "额度已更新"
                },
                new Scenario
                {
                    Name = "5小时 · 时间慷慨",
                    Gif = "06.gif",
                    Snapshot = Snapshot(92.0, 300.0, now.AddHours(3).AddMinutes(42).AddSeconds(18), now),
                    Expanded = true,
                    Status = "额度已更新"
                },
                new Scenario
                {
                    Name = "周额度 · 长倒计时",
                    Gif = "06.gif",
                    Snapshot = Snapshot(78.0, 10080.0, now.AddDays(6).AddHours(2).AddMinutes(3).AddSeconds(4), now),
                    Expanded = true,
                    Status = "额度已更新"
                },
                new Scenario
                {
                    Name = "15分钟 · 任意短窗",
                    Gif = "05.gif",
                    Snapshot = Snapshot(64.0, 15.0, now.AddMinutes(12).AddSeconds(18), now),
                    Expanded = true,
                    Status = "额度已更新"
                },
                new Scenario
                {
                    Name = "无限 · 格外慷慨",
                    Gif = "06.gif",
                    Snapshot = Unlimited(now),
                    Expanded = true,
                    Status = "额度已更新"
                },
                new Scenario
                {
                    Name = "耗尽 · 问答结束",
                    Gif = "01.gif",
                    Snapshot = Snapshot(0.0, now),
                    Expanded = true,
                    Status = "额度已更新"
                },
                new Scenario
                {
                    Name = "加载 · 谜底在路上",
                    Gif = "03.gif",
                    Loading = true,
                    Expanded = true,
                    Status = "正在连接 Codex…"
                },
                new Scenario
                {
                    Name = "断连 · 信号藏起",
                    Gif = "02.gif",
                    Snapshot = Snapshot(12.0, now),
                    Stale = true,
                    Expanded = true,
                    Status = "Codex 连接已断开，正在重连"
                },
                new Scenario
                {
                    Name = "无限断连 · 保留缓存",
                    Gif = "02.gif",
                    Snapshot = Unlimited(now),
                    Stale = true,
                    Expanded = true,
                    Status = "Codex 连接已断开，正在重连"
                }
            };

            int width = PanelWidth * scenarios.Length;
            int rowHeight = PanelHeight + CaptionHeight;
            int height = rowHeight * 3;
            using (Bitmap output = new Bitmap(width, height, PixelFormat.Format32bppArgb))
            using (Graphics graphics = Graphics.FromImage(output))
            using (Font captionFont = new Font("Microsoft YaHei UI", 9.5f, FontStyle.Bold))
            using (SolidBrush captionBrush = new SolidBrush(Color.FromArgb(45, 50, 103)))
            using (SolidBrush captionBackground = new SolidBrush(Color.White))
            using (Pen divider = new Pen(Color.FromArgb(203, 205, 220), 1.0f))
            {
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                for (int index = 0; index < scenarios.Length; index++)
                {
                    int offsetX = index * PanelWidth;
                    DrawCheckerboard(graphics, offsetX, 0, PanelWidth, PanelHeight);
                    DrawScenario(graphics, scenarios[index], offsetX, 0);
                    graphics.FillRectangle(
                        captionBackground,
                        offsetX,
                        PanelHeight,
                        PanelWidth,
                        CaptionHeight);
                    graphics.DrawString(
                        scenarios[index].Name + " · 棋盘格",
                        captionFont,
                        captionBrush,
                        new PointF(offsetX + 10.0f, PanelHeight + 6.0f));

                    using (SolidBrush darkBackground = new SolidBrush(Color.FromArgb(28, 30, 43)))
                    {
                        graphics.FillRectangle(
                            darkBackground,
                            offsetX,
                            rowHeight,
                            PanelWidth,
                            PanelHeight);
                    }
                    DrawScenario(graphics, scenarios[index], offsetX, rowHeight);
                    graphics.FillRectangle(
                        captionBackground,
                        offsetX,
                        rowHeight + PanelHeight,
                        PanelWidth,
                        CaptionHeight);
                    graphics.DrawString(
                        scenarios[index].Name + " · 深色",
                        captionFont,
                        captionBrush,
                        new PointF(offsetX + 10.0f, rowHeight + PanelHeight + 6.0f));

                    int blueTop = rowHeight * 2;
                    using (SolidBrush blueBackground = new SolidBrush(Color.FromArgb(0, 82, 196)))
                    {
                        graphics.FillRectangle(
                            blueBackground,
                            offsetX,
                            blueTop,
                            PanelWidth,
                            PanelHeight);
                    }
                    DrawScenario(graphics, scenarios[index], offsetX, blueTop);
                    graphics.FillRectangle(
                        captionBackground,
                        offsetX,
                        blueTop + PanelHeight,
                        PanelWidth,
                        CaptionHeight);
                    graphics.DrawString(
                        scenarios[index].Name + " · 蓝色桌面",
                        captionFont,
                        captionBrush,
                        new PointF(offsetX + 10.0f, blueTop + PanelHeight + 6.0f));
                    if (index > 0)
                    {
                        graphics.DrawLine(divider, offsetX, 0, offsetX, height);
                    }
                }
                graphics.DrawLine(divider, 0, rowHeight, width, rowHeight);
                graphics.DrawLine(divider, 0, rowHeight * 2, width, rowHeight * 2);

                string outputPath = Path.GetFullPath(args[0]);
                Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
                output.Save(outputPath, ImageFormat.Png);
                Console.WriteLine(outputPath);
            }
            return 0;
        }

        private static QuotaSnapshot Snapshot(double remaining, DateTime now)
        {
            return Snapshot(
                remaining,
                300.0,
                now.AddHours(3).AddMinutes(42).AddSeconds(18),
                now);
        }

        private static QuotaSnapshot Snapshot(
            double remaining,
            double windowMinutes,
            DateTime resetAtUtc,
            DateTime now)
        {
            return new QuotaSnapshot
            {
                UsedPercent = 100.0 - remaining,
                RemainingPercent = remaining,
                ResetAtUtc = resetAtUtc,
                UpdatedAtUtc = now,
                WindowDurationMins = windowMinutes,
                WindowDisplayName = QuotaWindowFormatter.Format(windowMinutes),
                LimitId = "codex"
            };
        }

        private static QuotaSnapshot Unlimited(DateTime now)
        {
            return new QuotaSnapshot
            {
                UsedPercent = 0.0,
                RemainingPercent = 100.0,
                ResetAtUtc = DateTime.MaxValue,
                UpdatedAtUtc = now,
                WindowDisplayName = "无限",
                IsUnlimited = true
            };
        }

        private static void DrawScenario(
            Graphics graphics,
            Scenario scenario,
            int offsetX,
            int offsetY)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            using (Stream stream = assembly.GetManifestResourceStream(
                "CodexQuotaPet.DisplayAssets." + scenario.Gif))
            using (Image pet = Image.FromStream(stream, true, true))
            {
                graphics.DrawImageUnscaled(pet, offsetX + 32, offsetY + 82);
            }

            using (QuotaCard card = new QuotaCard())
            {
                if (scenario.Loading)
                {
                    card.SetWorking(scenario.Snapshot, scenario.Status);
                }
                else
                {
                    card.SetSnapshot(scenario.Snapshot, scenario.Stale, scenario.Status);
                }
                card.SetExpanded(scenario.Expanded, false);
                card.CreateControl();

                using (Bitmap cardBitmap = new Bitmap(
                    card.Width,
                    card.Height,
                    PixelFormat.Format32bppArgb))
                using (ImageAttributes colorKey = new ImageAttributes())
                {
                    card.DrawToBitmap(cardBitmap, new Rectangle(Point.Empty, card.Size));
                    colorKey.SetColorKey(PetForm.TransparencyColor, PetForm.TransparencyColor);
                    graphics.DrawImage(
                        cardBitmap,
                        new Rectangle(
                            offsetX + card.Left,
                            offsetY + card.Top,
                            card.Width,
                            card.Height),
                        0,
                        0,
                        card.Width,
                        card.Height,
                        GraphicsUnit.Pixel,
                        colorKey);
                }
            }
        }

        private static void DrawCheckerboard(
            Graphics graphics,
            int left,
            int top,
            int width,
            int height)
        {
            const int cell = 16;
            Color first = Color.FromArgb(239, 241, 247);
            Color second = Color.FromArgb(218, 222, 232);
            for (int y = top; y < top + height; y += cell)
            {
                for (int x = left; x < left + width; x += cell)
                {
                    bool alternate = (((x - left) / cell) + ((y - top) / cell)) % 2 == 0;
                    using (SolidBrush brush = new SolidBrush(alternate ? first : second))
                    {
                        graphics.FillRectangle(brush, x, y, cell, cell);
                    }
                }
            }
        }
    }
}

using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace CodexQuotaPet
{
    internal static class Program
    {
        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool SetProcessDpiAwarenessContext(IntPtr dpiContext);

        [STAThread]
        private static void Main()
        {
            bool createdNew;
            using (Mutex mutex = new Mutex(
                true,
                @"Local\CodexQuotaPet.Singleton.v1",
                out createdNew))
            {
                if (!createdNew)
                {
                    return;
                }

                try
                {
                    SetProcessDpiAwarenessContext(new IntPtr(-4));
                }
                catch (Exception)
                {
                }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new PetForm());
                GC.KeepAlive(mutex);
            }
        }
    }
}

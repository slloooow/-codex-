using System;
using System.Collections.Generic;
using System.Globalization;
using System.Web.Script.Serialization;

namespace CodexQuotaPet
{
    internal sealed class QuotaSnapshot
    {
        public double UsedPercent { get; set; }
        public double RemainingPercent { get; set; }
        public DateTime ResetAtUtc { get; set; }
        public DateTime UpdatedAtUtc { get; set; }
        public double WindowDurationMins { get; set; }
        public string LimitId { get; set; }
        public string LimitName { get; set; }
        public string WindowDisplayName { get; set; }
        public bool IsUnlimited { get; set; }
    }

    internal static class QuotaWindowFormatter
    {
        public static string Format(double minutes)
        {
            if (!IsPositiveFinite(minutes))
            {
                return "额度";
            }

            if (Math.Abs(minutes - 10080.0) <= 0.01)
            {
                return "周额度";
            }

            double days = minutes / 1440.0;
            if (IsWhole(days))
            {
                return FormatWhole(days) + "天额度";
            }

            double hours = minutes / 60.0;
            if (IsWhole(hours))
            {
                return FormatWhole(hours) + "小时额度";
            }

            return minutes.ToString("0.##", CultureInfo.InvariantCulture) + "分钟额度";
        }

        private static bool IsWhole(double value)
        {
            return Math.Abs(value - Math.Round(value)) <= 0.000001;
        }

        private static string FormatWhole(double value)
        {
            return Math.Round(value).ToString("0", CultureInfo.InvariantCulture);
        }

        private static bool IsPositiveFinite(double value)
        {
            return value > 0.0 && !Double.IsNaN(value) && !Double.IsInfinity(value);
        }
    }

    internal static class QuotaParser
    {
        private static readonly DateTime UnixEpoch =
            new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        private sealed class WindowCandidate
        {
            public string BucketKey;
            public string LimitId;
            public string LimitName;
            public int RolePriority;
            public double UsedPercent;
            public double WindowMinutes;
            public DateTime ResetAtUtc;
        }

        public static bool TryParse(string json, out QuotaSnapshot snapshot, out string error)
        {
            snapshot = null;
            error = null;

            if (String.IsNullOrWhiteSpace(json))
            {
                error = "额度响应为空";
                return false;
            }

            Dictionary<string, object> root;
            try
            {
                root = new JavaScriptSerializer().DeserializeObject(json) as Dictionary<string, object>;
            }
            catch (Exception)
            {
                error = "额度响应不是有效 JSON";
                return false;
            }

            if (root == null)
            {
                error = "额度响应格式不受支持";
                return false;
            }

            Dictionary<string, object> container = root;
            Dictionary<string, object> nested;
            if (TryDictionary(root, "result", out nested))
            {
                container = nested;
            }
            else if (TryDictionary(root, "params", out nested))
            {
                container = nested;
            }

            object rawById;
            if (container.TryGetValue("rateLimitsByLimitId", out rawById))
            {
                if (rawById == null)
                {
                    snapshot = UnlimitedSnapshot();
                    return true;
                }

                Dictionary<string, object> byId = rawById as Dictionary<string, object>;
                if (byId == null)
                {
                    error = "多额度桶格式无效";
                    return false;
                }

                return TryParseMultiBucket(byId, out snapshot, out error);
            }

            object rawSingle;
            if (container.TryGetValue("rateLimits", out rawSingle))
            {
                if (rawSingle == null)
                {
                    snapshot = UnlimitedSnapshot();
                    return true;
                }

                Dictionary<string, object> single = rawSingle as Dictionary<string, object>;
                if (single == null)
                {
                    error = "单额度桶格式无效";
                    return false;
                }

                return TryParseSingleBucket(single, "codex", out snapshot, out error);
            }

            if (container.ContainsKey("primary") || container.ContainsKey("secondary"))
            {
                return TryParseSingleBucket(container, "codex", out snapshot, out error);
            }

            error = "额度响应缺少额度窗口集合";
            return false;
        }

        private static bool TryParseMultiBucket(
            Dictionary<string, object> byId,
            out QuotaSnapshot snapshot,
            out string error)
        {
            snapshot = null;
            error = null;

            if (byId.Count == 0)
            {
                snapshot = UnlimitedSnapshot();
                return true;
            }

            List<WindowCandidate> mainCandidates = new List<WindowCandidate>();
            List<WindowCandidate> fallbackCandidates = new List<WindowCandidate>();
            bool malformed = false;
            bool explicitWindowSurface = false;

            foreach (KeyValuePair<string, object> pair in byId)
            {
                if (pair.Value == null)
                {
                    explicitWindowSurface = true;
                    continue;
                }

                Dictionary<string, object> bucket = pair.Value as Dictionary<string, object>;
                if (bucket == null)
                {
                    malformed = true;
                    continue;
                }

                List<WindowCandidate> target = String.Equals(
                    pair.Key,
                    "codex",
                    StringComparison.OrdinalIgnoreCase)
                    ? mainCandidates
                    : fallbackCandidates;
                CollectBucketCandidates(
                    bucket,
                    pair.Key,
                    target,
                    ref malformed,
                    ref explicitWindowSurface);
            }

            List<WindowCandidate> selectionPool =
                mainCandidates.Count > 0 ? mainCandidates : fallbackCandidates;
            if (selectionPool.Count > 0)
            {
                selectionPool.Sort(CompareCandidates);
                snapshot = SnapshotFromCandidate(selectionPool[0]);
                return true;
            }

            if (malformed || !explicitWindowSurface)
            {
                error = "额度窗口字段缺失或格式无效";
                return false;
            }

            snapshot = UnlimitedSnapshot();
            return true;
        }

        private static bool TryParseSingleBucket(
            Dictionary<string, object> bucket,
            string fallbackLimitId,
            out QuotaSnapshot snapshot,
            out string error)
        {
            snapshot = null;
            error = null;
            List<WindowCandidate> candidates = new List<WindowCandidate>();
            bool malformed = false;
            bool explicitWindowSurface = false;
            CollectBucketCandidates(
                bucket,
                fallbackLimitId,
                candidates,
                ref malformed,
                ref explicitWindowSurface);

            if (candidates.Count > 0)
            {
                candidates.Sort(CompareCandidates);
                snapshot = SnapshotFromCandidate(candidates[0]);
                return true;
            }

            if (malformed || !explicitWindowSurface)
            {
                error = "额度窗口字段缺失或格式无效";
                return false;
            }

            snapshot = UnlimitedSnapshot();
            return true;
        }

        private static void CollectBucketCandidates(
            Dictionary<string, object> bucket,
            string bucketKey,
            List<WindowCandidate> candidates,
            ref bool malformed,
            ref bool explicitWindowSurface)
        {
            bool hasPrimary = bucket.ContainsKey("primary");
            bool hasSecondary = bucket.ContainsKey("secondary");
            if (!hasPrimary && !hasSecondary)
            {
                malformed = true;
                return;
            }

            if (hasPrimary)
            {
                explicitWindowSurface = true;
                CollectWindow(
                    bucket,
                    "primary",
                    0,
                    bucketKey,
                    candidates,
                    ref malformed);
            }

            if (hasSecondary)
            {
                explicitWindowSurface = true;
                CollectWindow(
                    bucket,
                    "secondary",
                    1,
                    bucketKey,
                    candidates,
                    ref malformed);
            }
        }

        private static void CollectWindow(
            Dictionary<string, object> bucket,
            string role,
            int rolePriority,
            string bucketKey,
            List<WindowCandidate> candidates,
            ref bool malformed)
        {
            object rawWindow;
            if (!bucket.TryGetValue(role, out rawWindow) || rawWindow == null)
            {
                return;
            }

            Dictionary<string, object> window = rawWindow as Dictionary<string, object>;
            if (window == null)
            {
                malformed = true;
                return;
            }

            double usedPercent;
            double windowMinutes;
            double resetAtSeconds;
            if (!TryNumber(window, "usedPercent", out usedPercent) ||
                !TryNumber(window, "windowDurationMins", out windowMinutes) ||
                windowMinutes <= 0.0 ||
                !TryNumber(window, "resetsAt", out resetAtSeconds))
            {
                malformed = true;
                return;
            }

            DateTime resetAtUtc;
            try
            {
                resetAtUtc = UnixEpoch.AddSeconds(resetAtSeconds);
            }
            catch (ArgumentOutOfRangeException)
            {
                malformed = true;
                return;
            }

            string limitId = GetOptionalString(bucket, "limitId");
            string limitName = GetOptionalString(bucket, "limitName");
            candidates.Add(new WindowCandidate
            {
                BucketKey = bucketKey ?? String.Empty,
                LimitId = String.IsNullOrWhiteSpace(limitId) ? bucketKey : limitId,
                LimitName = limitName,
                RolePriority = rolePriority,
                UsedPercent = Math.Max(0.0, Math.Min(100.0, usedPercent)),
                WindowMinutes = windowMinutes,
                ResetAtUtc = resetAtUtc
            });
        }

        private static int CompareCandidates(WindowCandidate left, WindowCandidate right)
        {
            int duration = left.WindowMinutes.CompareTo(right.WindowMinutes);
            if (duration != 0)
            {
                return duration;
            }

            int role = left.RolePriority.CompareTo(right.RolePriority);
            if (role != 0)
            {
                return role;
            }

            return StringComparer.Ordinal.Compare(left.BucketKey, right.BucketKey);
        }

        private static QuotaSnapshot SnapshotFromCandidate(WindowCandidate candidate)
        {
            return new QuotaSnapshot
            {
                UsedPercent = candidate.UsedPercent,
                RemainingPercent = Math.Max(0.0, Math.Min(100.0, 100.0 - candidate.UsedPercent)),
                ResetAtUtc = candidate.ResetAtUtc,
                UpdatedAtUtc = DateTime.UtcNow,
                WindowDurationMins = candidate.WindowMinutes,
                LimitId = candidate.LimitId,
                LimitName = candidate.LimitName,
                WindowDisplayName = QuotaWindowFormatter.Format(candidate.WindowMinutes),
                IsUnlimited = false
            };
        }

        private static QuotaSnapshot UnlimitedSnapshot()
        {
            return new QuotaSnapshot
            {
                UsedPercent = 0.0,
                RemainingPercent = 100.0,
                ResetAtUtc = DateTime.MaxValue,
                UpdatedAtUtc = DateTime.UtcNow,
                WindowDurationMins = 0.0,
                LimitId = null,
                LimitName = null,
                WindowDisplayName = "无限",
                IsUnlimited = true
            };
        }

        private static bool TryDictionary(
            Dictionary<string, object> source,
            string key,
            out Dictionary<string, object> result)
        {
            result = null;
            object value;
            if (source == null || !source.TryGetValue(key, out value))
            {
                return false;
            }

            result = value as Dictionary<string, object>;
            return result != null;
        }

        private static string GetOptionalString(Dictionary<string, object> source, string key)
        {
            object value;
            if (source == null || !source.TryGetValue(key, out value) || value == null)
            {
                return null;
            }

            return value as string;
        }

        private static bool TryNumber(
            Dictionary<string, object> source,
            string key,
            out double result)
        {
            result = 0.0;
            object value;
            if (source == null || !source.TryGetValue(key, out value) || value == null)
            {
                return false;
            }

            try
            {
                result = Convert.ToDouble(value, CultureInfo.InvariantCulture);
                return !Double.IsNaN(result) && !Double.IsInfinity(result);
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}

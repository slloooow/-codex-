using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

namespace CodexQuotaPet
{
    internal sealed class AppServerClient : IDisposable
    {
        private readonly object _sync = new object();
        private readonly Timer _pollTimer;
        private readonly Timer _reconnectTimer;
        private readonly Timer _handshakeTimer;
        private Process _process;
        private StreamWriter _writer;
        private bool _initialized;
        private bool _disposed;
        private int _requestId = 10;
        private int _pendingRateLimitRequestId = -1;
        private DateTime _pendingRateLimitRequestUtc = DateTime.MinValue;
        private int _backoffIndex;
        private DateTime _lastSuccessUtc = DateTime.MinValue;

        public event Action<QuotaSnapshot> QuotaUpdated;
        public event Action<string, bool> StatusChanged;

        public AppServerClient()
        {
            _pollTimer = new Timer(Poll, null, Timeout.Infinite, Timeout.Infinite);
            _reconnectTimer = new Timer(Reconnect, null, Timeout.Infinite, Timeout.Infinite);
            _handshakeTimer = new Timer(HandshakeTimedOut, null, Timeout.Infinite, Timeout.Infinite);
        }

        public void Start()
        {
            _reconnectTimer.Change(0, Timeout.Infinite);
        }

        public void Refresh()
        {
            bool restart = false;
            lock (_sync)
            {
                if (_disposed)
                {
                    return;
                }

                if (_process == null || _process.HasExited)
                {
                    _reconnectTimer.Change(0, Timeout.Infinite);
                    return;
                }

                if (_initialized)
                {
                    try
                    {
                        SendRateLimitRequestLocked();
                    }
                    catch (Exception)
                    {
                        restart = true;
                    }
                }
            }

            if (restart)
            {
                RaiseStatus("Codex 连接已断开，正在重连", true);
                QueueRestart();
            }
        }

        private void Reconnect(object state)
        {
            StartProcess();
        }

        private void StartProcess()
        {
            string launcher = FindCodexLauncher();
            if (launcher == null)
            {
                RaiseStatus("找不到 Codex CLI，请先安装或更新 Codex", true);
                ScheduleReconnect();
                return;
            }

            try
            {
                ProcessStartInfo startInfo = BuildStartInfo(launcher);
                Process process = new Process();
                process.StartInfo = startInfo;
                process.EnableRaisingEvents = true;
                process.OutputDataReceived += ProcessOutputDataReceived;
                process.ErrorDataReceived += ProcessErrorDataReceived;
                process.Exited += ProcessExited;

                lock (_sync)
                {
                    if (_disposed)
                    {
                        process.Dispose();
                        return;
                    }

                    StopProcessLocked();
                    _process = process;
                    _initialized = false;
                    ClearPendingRateLimitRequestLocked();
                }

                if (!process.Start())
                {
                    throw new InvalidOperationException("Codex App Server 未启动");
                }

                process.BeginOutputReadLine();
                process.BeginErrorReadLine();

                lock (_sync)
                {
                    if (!ReferenceEquals(_process, process))
                    {
                        return;
                    }

                    _writer = new StreamWriter(
                        process.StandardInput.BaseStream,
                        new UTF8Encoding(false));
                    _writer.AutoFlush = true;
                    // .NET Framework's Process.StandardInput accessor emits a UTF-8 BOM
                    // before exposing the underlying pipe. Put that BOM on its own line;
                    // App Server ignores the malformed preface and reads subsequent JSONL.
                    _writer.WriteLine();
                    SendLocked(
                        "{\"method\":\"initialize\",\"id\":0,\"params\":{" +
                        "\"clientInfo\":{\"name\":\"codex_quota_pet\"," +
                        "\"title\":\"Codex Quota Pet\",\"version\":\"1.0.0\"}}}");
                }

                RaiseStatus("正在连接 Codex…", false);
                _handshakeTimer.Change(15000, Timeout.Infinite);
            }
            catch (Exception)
            {
                RaiseStatus("无法启动 Codex App Server", true);
                lock (_sync)
                {
                    StopProcessLocked();
                }
                ScheduleReconnect();
            }
        }

        private static ProcessStartInfo BuildStartInfo(string launcher)
        {
            ProcessStartInfo info = new ProcessStartInfo();
            if (launcher.EndsWith(".cmd", StringComparison.OrdinalIgnoreCase) ||
                launcher.EndsWith(".bat", StringComparison.OrdinalIgnoreCase))
            {
                info.FileName = Environment.GetEnvironmentVariable("ComSpec") ?? "cmd.exe";
                info.Arguments = "/d /s /c \"\"" + launcher + "\" app-server\"";
            }
            else
            {
                info.FileName = launcher;
                info.Arguments = "app-server";
            }

            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            info.WindowStyle = ProcessWindowStyle.Hidden;
            info.RedirectStandardInput = true;
            info.RedirectStandardOutput = true;
            info.RedirectStandardError = true;
            info.StandardOutputEncoding = Encoding.UTF8;
            info.StandardErrorEncoding = Encoding.UTF8;
            return info;
        }

        private static string FindCodexLauncher()
        {
            string overridePath = Environment.GetEnvironmentVariable("CODEX_QUOTA_PET_CODEX");
            if (!String.IsNullOrWhiteSpace(overridePath) && File.Exists(overridePath))
            {
                return overridePath;
            }

            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string native = Path.Combine(
                appData,
                @"npm\node_modules\@openai\codex\node_modules\@openai\codex-win32-x64\vendor\x86_64-pc-windows-msvc\bin\codex.exe");
            if (File.Exists(native))
            {
                return native;
            }

            string command = Path.Combine(appData, @"npm\codex.cmd");
            if (File.Exists(command))
            {
                return command;
            }

            return null;
        }

        private void ProcessOutputDataReceived(object sender, DataReceivedEventArgs args)
        {
            if (String.IsNullOrWhiteSpace(args.Data))
            {
                return;
            }

            HandleLine(args.Data);
        }

        private void HandleLine(string line)
        {
            Dictionary<string, object> root = null;
            try
            {
                root = new JavaScriptSerializer().DeserializeObject(line) as Dictionary<string, object>;
            }
            catch (Exception)
            {
                return;
            }

            if (root == null)
            {
                return;
            }

            object methodObject;
            if (root.TryGetValue("method", out methodObject) &&
                String.Equals(
                    Convert.ToString(methodObject),
                    "account/rateLimits/updated",
                    StringComparison.Ordinal))
            {
                RequestFullReadAfterNotification();
                return;
            }

            object idObject;
            if (root.TryGetValue("id", out idObject) && Convert.ToString(idObject) == "0")
            {
                Dictionary<string, object> result;
                if (TryDictionary(root, "result", out result))
                {
                    bool restart = false;
                    lock (_sync)
                    {
                        if (_disposed || _process == null)
                        {
                            return;
                        }

                        try
                        {
                            _initialized = true;
                            SendLocked("{\"method\":\"initialized\",\"params\":{}}");
                            SendRateLimitRequestLocked();
                            _pollTimer.Change(60000, 60000);
                            _handshakeTimer.Change(Timeout.Infinite, Timeout.Infinite);
                        }
                        catch (Exception)
                        {
                            _initialized = false;
                            restart = true;
                        }
                    }

                    if (restart)
                    {
                        RaiseStatus("Codex 连接已断开，正在重连", true);
                        QueueRestart();
                    }
                    return;
                }
            }

            int responseId;
            bool isRateLimitResponse = TryResponseId(root, out responseId) &&
                                       ClearPendingIfMatched(responseId);

            object errorObject;
            if (root.TryGetValue("error", out errorObject) && errorObject != null)
            {
                RaiseStatus("Codex 暂时无法返回额度，请检查登录状态", true);
                QueueRestart();
                return;
            }

            if (!isRateLimitResponse)
            {
                return;
            }

            QuotaSnapshot snapshot;
            string parseError;
            if (QuotaParser.TryParse(line, out snapshot, out parseError))
            {
                _lastSuccessUtc = DateTime.UtcNow;
                _backoffIndex = 0;
                RaiseStatus("额度已更新", false);
                Action<QuotaSnapshot> handler = QuotaUpdated;
                if (handler != null)
                {
                    handler(snapshot);
                }
            }
            else
            {
                RaiseStatus(
                    String.IsNullOrWhiteSpace(parseError)
                        ? "额度响应格式暂不兼容，等待更新"
                        : parseError + "，等待更新",
                    true);
            }
        }

        private void RequestFullReadAfterNotification()
        {
            bool restart = false;
            lock (_sync)
            {
                if (_disposed || !_initialized || _writer == null)
                {
                    return;
                }

                try
                {
                    SendRateLimitRequestLocked();
                }
                catch (Exception)
                {
                    restart = true;
                }
            }

            if (restart)
            {
                RaiseStatus("Codex 连接已断开，正在重连", true);
                QueueRestart();
            }
        }

        private bool ClearPendingIfMatched(int responseId)
        {
            lock (_sync)
            {
                if (responseId != _pendingRateLimitRequestId)
                {
                    return false;
                }

                ClearPendingRateLimitRequestLocked();
                return true;
            }
        }

        private static bool TryResponseId(
            Dictionary<string, object> root,
            out int responseId)
        {
            responseId = -1;
            object rawId;
            if (root == null || !root.TryGetValue("id", out rawId) || rawId == null)
            {
                return false;
            }

            return Int32.TryParse(Convert.ToString(rawId), out responseId);
        }

        private static bool TryDictionary(
            Dictionary<string, object> source,
            string key,
            out Dictionary<string, object> value)
        {
            value = null;
            object raw;
            if (!source.TryGetValue(key, out raw))
            {
                return false;
            }

            value = raw as Dictionary<string, object>;
            return value != null;
        }

        private void ProcessErrorDataReceived(object sender, DataReceivedEventArgs args)
        {
            // App Server writes diagnostics to stderr. They may contain local paths,
            // so the desktop widget deliberately does not persist or display them.
        }

        private void ProcessExited(object sender, EventArgs args)
        {
            Process exited = sender as Process;
            lock (_sync)
            {
                if (_disposed || !ReferenceEquals(_process, exited))
                {
                    return;
                }

                _process = null;
                _writer = null;
                _initialized = false;
                ClearPendingRateLimitRequestLocked();
                _pollTimer.Change(Timeout.Infinite, Timeout.Infinite);
            }

            RaiseStatus("Codex 连接已断开，正在重连", true);
            ScheduleReconnect();
        }

        private void Poll(object state)
        {
            bool restart = false;
            lock (_sync)
            {
                if (_disposed || !_initialized || _writer == null)
                {
                    return;
                }

                try
                {
                    SendRateLimitRequestLocked();
                }
                catch (Exception)
                {
                    restart = true;
                }
            }

            if (restart)
            {
                RaiseStatus("Codex 连接已断开，正在重连", true);
                QueueRestart();
                return;
            }

            if (_lastSuccessUtc != DateTime.MinValue &&
                DateTime.UtcNow - _lastSuccessUtc > TimeSpan.FromMinutes(2))
            {
                RaiseStatus("额度数据等待更新", true);
            }
        }

        private void SendRateLimitRequestLocked()
        {
            if (_pendingRateLimitRequestId >= 0 &&
                DateTime.UtcNow - _pendingRateLimitRequestUtc < TimeSpan.FromSeconds(30))
            {
                return;
            }

            ClearPendingRateLimitRequestLocked();
            int id = _requestId++;
            _pendingRateLimitRequestId = id;
            _pendingRateLimitRequestUtc = DateTime.UtcNow;
            try
            {
                SendLocked("{\"method\":\"account/rateLimits/read\",\"id\":" + id + "}");
            }
            catch (Exception)
            {
                ClearPendingRateLimitRequestLocked();
                throw;
            }
        }

        private void ClearPendingRateLimitRequestLocked()
        {
            _pendingRateLimitRequestId = -1;
            _pendingRateLimitRequestUtc = DateTime.MinValue;
        }

        private void SendLocked(string json)
        {
            if (_writer == null)
            {
                throw new InvalidOperationException("Codex App Server 未连接");
            }

            _writer.WriteLine(json);
            _writer.Flush();
        }

        private void HandshakeTimedOut(object state)
        {
            lock (_sync)
            {
                if (_disposed || _initialized)
                {
                    return;
                }
            }

            RaiseStatus("Codex 连接超时，正在重试", true);
            QueueRestart();
        }

        private void QueueRestart()
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                lock (_sync)
                {
                    StopProcessLocked();
                }
                ScheduleReconnect();
            });
        }

        private void ScheduleReconnect()
        {
            int[] delays = { 5, 15, 60, 300 };
            int index = Math.Min(_backoffIndex, delays.Length - 1);
            int seconds = delays[index];
            if (_backoffIndex < delays.Length - 1)
            {
                _backoffIndex++;
            }

            if (!_disposed)
            {
                _reconnectTimer.Change(seconds * 1000, Timeout.Infinite);
            }
        }

        private void RaiseStatus(string message, bool stale)
        {
            Action<string, bool> handler = StatusChanged;
            if (handler != null)
            {
                handler(message, stale);
            }
        }

        private void StopProcessLocked()
        {
            Process process = _process;
            _process = null;
            _writer = null;
            _initialized = false;
            ClearPendingRateLimitRequestLocked();
            _pollTimer.Change(Timeout.Infinite, Timeout.Infinite);
            _handshakeTimer.Change(Timeout.Infinite, Timeout.Infinite);

            if (process == null)
            {
                return;
            }

            try
            {
                if (!process.HasExited)
                {
                    try
                    {
                        process.StandardInput.Close();
                    }
                    catch (Exception)
                    {
                    }

                    if (!process.WaitForExit(500))
                    {
                        process.Kill();
                    }
                }
            }
            catch (Exception)
            {
            }
            finally
            {
                process.Dispose();
            }
        }

        public void Dispose()
        {
            lock (_sync)
            {
                if (_disposed)
                {
                    return;
                }

                _disposed = true;
                StopProcessLocked();
            }

            _pollTimer.Dispose();
            _reconnectTimer.Dispose();
            _handshakeTimer.Dispose();
        }
    }
}

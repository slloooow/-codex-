using System;
using System.IO;
using System.Reflection;
using System.Text;

namespace CodexQuotaPet
{
    internal static class AppServerClientTests
    {
        private const BindingFlags PrivateInstance =
            BindingFlags.Instance | BindingFlags.NonPublic;

        private static int _passed;

        private static void Main()
        {
            using (MemoryStream output = new MemoryStream())
            using (StreamWriter writer = new StreamWriter(output, new UTF8Encoding(false)))
            using (AppServerClient client = new AppServerClient())
            {
                writer.AutoFlush = true;
                SetField(client, "_writer", writer);
                SetField(client, "_initialized", true);

                int updates = 0;
                client.QuotaUpdated += delegate { updates++; };

                InvokeHandleLine(
                    client,
                    "{\"method\":\"account/rateLimits/updated\",\"params\":{" +
                    "\"rateLimits\":{\"primary\":{\"usedPercent\":99," +
                    "\"windowDurationMins\":5,\"resetsAt\":1788010858}}}}" );
                Expect(0, updates, "partial notification does not overwrite snapshot");
                Expect(1, CountReads(output), "notification triggers one full read");

                InvokeHandleLine(
                    client,
                    "{\"method\":\"account/rateLimits/updated\",\"params\":{}}" );
                Expect(1, CountReads(output), "pending full read is coalesced");

                InvokeHandleLine(
                    client,
                    "{\"id\":10,\"result\":{\"rateLimitsByLimitId\":{}}}" );
                Expect(1, updates, "full read response updates snapshot");

                InvokeHandleLine(
                    client,
                    "{\"method\":\"account/rateLimits/updated\",\"params\":{}}" );
                Expect(2, CountReads(output), "new notification refreshes after response");
            }

            Console.WriteLine("PASS: " + _passed + " App Server notification assertions");
        }

        private static int CountReads(MemoryStream output)
        {
            string content = Encoding.UTF8.GetString(output.ToArray());
            int count = 0;
            int index = 0;
            const string marker = "account/rateLimits/read";
            while ((index = content.IndexOf(marker, index, StringComparison.Ordinal)) >= 0)
            {
                count++;
                index += marker.Length;
            }
            return count;
        }

        private static void InvokeHandleLine(AppServerClient client, string line)
        {
            MethodInfo method = typeof(AppServerClient).GetMethod("HandleLine", PrivateInstance);
            if (method == null)
            {
                throw new MissingMethodException(typeof(AppServerClient).FullName, "HandleLine");
            }
            method.Invoke(client, new object[] { line });
        }

        private static void SetField(AppServerClient client, string name, object value)
        {
            FieldInfo field = typeof(AppServerClient).GetField(name, PrivateInstance);
            if (field == null)
            {
                throw new MissingFieldException(typeof(AppServerClient).FullName, name);
            }
            field.SetValue(client, value);
        }

        private static void Expect(int expected, int actual, string name)
        {
            if (expected != actual)
            {
                throw new Exception(name + ": expected " + expected + ", actual " + actual);
            }
            _passed++;
        }
    }
}

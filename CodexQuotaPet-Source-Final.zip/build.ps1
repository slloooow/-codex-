$ErrorActionPreference = 'Stop'

$sourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$binDir = Join-Path $sourceRoot 'bin'
$csc = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'

if (-not (Test-Path -LiteralPath $csc)) {
    throw '.NET Framework C# compiler was not found.'
}

New-Item -ItemType Directory -Force -Path $binDir | Out-Null

$references = @(
    '/reference:System.dll',
    '/reference:System.Core.dll',
    '/reference:System.Drawing.dll',
    '/reference:System.Windows.Forms.dll',
    '/reference:System.Web.Extensions.dll'
)

$resources = 1..6 | ForEach-Object {
    $name = '{0:00}.gif' -f $_
    '/resource:{0},CodexQuotaPet.DisplayAssets.{1}' -f (Join-Path $sourceRoot ('DisplayAssets\' + $name)), $name
}

$appSources = @(
    (Join-Path $sourceRoot 'Program.cs'),
    (Join-Path $sourceRoot 'QuotaModel.cs'),
    (Join-Path $sourceRoot 'SettingsStore.cs'),
    (Join-Path $sourceRoot 'AppServerClient.cs'),
    (Join-Path $sourceRoot 'PetBehavior.cs'),
    (Join-Path $sourceRoot 'QuotaSpeech.cs'),
    (Join-Path $sourceRoot 'QuotaCard.cs'),
    (Join-Path $sourceRoot 'PetForm.cs')
)

$appArgs = @(
    '/nologo',
    '/target:winexe',
    '/optimize+',
    '/platform:anycpu',
    ('/win32manifest:{0}' -f (Join-Path $sourceRoot 'app.manifest')),
    ('/out:{0}' -f (Join-Path $binDir 'CodexQuotaPet.exe'))
) + $references + $resources + $appSources

& $csc $appArgs
if ($LASTEXITCODE -ne 0) { throw 'CodexQuotaPet compilation failed.' }

$testArgs = @(
    '/nologo',
    '/target:exe',
    '/optimize+',
    ('/out:{0}' -f (Join-Path $binDir 'ParserTests.exe'))
) + $references + @(
    (Join-Path $sourceRoot 'QuotaModel.cs'),
    (Join-Path $sourceRoot 'ParserTests.cs')
)

& $csc $testArgs
if ($LASTEXITCODE -ne 0) { throw 'ParserTests compilation failed.' }

$appServerTestArgs = @(
    '/nologo',
    '/target:exe',
    '/optimize+',
    ('/out:{0}' -f (Join-Path $binDir 'AppServerClientTests.exe'))
) + $references + @(
    (Join-Path $sourceRoot 'QuotaModel.cs'),
    (Join-Path $sourceRoot 'AppServerClient.cs'),
    (Join-Path $sourceRoot 'AppServerClientTests.cs')
)

& $csc $appServerTestArgs
if ($LASTEXITCODE -ne 0) { throw 'AppServerClientTests compilation failed.' }

$behaviorTestArgs = @(
    '/nologo',
    '/target:exe',
    '/optimize+',
    ('/out:{0}' -f (Join-Path $binDir 'PetBehaviorTests.exe'))
) + $references + @(
    (Join-Path $sourceRoot 'PetBehavior.cs'),
    (Join-Path $sourceRoot 'PetBehaviorTests.cs')
)

& $csc $behaviorTestArgs
if ($LASTEXITCODE -ne 0) { throw 'PetBehaviorTests compilation failed.' }

$speechTestArgs = @(
    '/nologo',
    '/target:exe',
    '/optimize+',
    ('/out:{0}' -f (Join-Path $binDir 'QuotaSpeechTests.exe'))
) + $references + @(
    (Join-Path $sourceRoot 'QuotaModel.cs'),
    (Join-Path $sourceRoot 'QuotaSpeech.cs'),
    (Join-Path $sourceRoot 'QuotaSpeechTests.cs')
)

& $csc $speechTestArgs
if ($LASTEXITCODE -ne 0) { throw 'QuotaSpeechTests compilation failed.' }

$probeArgs = @(
    '/nologo',
    '/target:exe',
    '/optimize+',
    ('/out:{0}' -f (Join-Path $binDir 'LiveProbe.exe'))
) + $references + @(
    (Join-Path $sourceRoot 'QuotaModel.cs'),
    (Join-Path $sourceRoot 'AppServerClient.cs'),
    (Join-Path $sourceRoot 'LiveProbe.cs')
)

& $csc $probeArgs
if ($LASTEXITCODE -ne 0) { throw 'LiveProbe compilation failed.' }

$assetTestArgs = @(
    '/nologo',
    '/target:exe',
    '/optimize+',
    ('/out:{0}' -f (Join-Path $binDir 'AssetTests.exe'))
) + $references + @(
    (Join-Path $sourceRoot 'AssetTests.cs')
)

& $csc $assetTestArgs
if ($LASTEXITCODE -ne 0) { throw 'AssetTests compilation failed.' }

$visualProbeArgs = @(
    '/nologo',
    '/target:exe',
    '/optimize+',
    '/main:CodexQuotaPet.VisualProbe',
    ('/out:{0}' -f (Join-Path $binDir 'VisualProbe.exe'))
) + $references + $resources + $appSources + @(
    (Join-Path $sourceRoot 'VisualProbe.cs')
)

& $csc $visualProbeArgs
if ($LASTEXITCODE -ne 0) { throw 'VisualProbe compilation failed.' }

$interactionTestArgs = @(
    '/nologo',
    '/target:exe',
    '/optimize+',
    '/main:CodexQuotaPet.PetInteractionTests',
    ('/out:{0}' -f (Join-Path $binDir 'PetInteractionTests.exe'))
) + $references + $resources + $appSources + @(
    (Join-Path $sourceRoot 'PetInteractionTests.cs')
)

& $csc $interactionTestArgs
if ($LASTEXITCODE -ne 0) { throw 'PetInteractionTests compilation failed.' }

$contactSheetArgs = @(
    '/nologo',
    '/target:exe',
    '/optimize+',
    ('/out:{0}' -f (Join-Path $binDir 'GifActionContactSheet.exe'))
) + $references + @(
    (Join-Path $sourceRoot 'tools\GifActionContactSheet.cs')
)

& $csc $contactSheetArgs
if ($LASTEXITCODE -ne 0) { throw 'GifActionContactSheet compilation failed.' }

Get-ChildItem -LiteralPath $binDir -Filter '*.exe' |
    Select-Object Name, Length, @{Name='SHA256';Expression={(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}} |
    Format-Table -AutoSize

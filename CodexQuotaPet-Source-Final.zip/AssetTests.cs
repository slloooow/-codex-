using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

namespace CodexQuotaPet
{
    internal static class AssetTests
    {
        private static readonly int[] ExpectedFrameCounts = { 17, 17, 31, 41, 41, 61 };

        private static int Main(string[] args)
        {
            string assetRoot = args.Length > 0
                ? Path.GetFullPath(args[0])
                : Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets");
            string originalRoot = args.Length > 1
                ? Path.GetFullPath(args[1])
                : null;
            string displayRoot = args.Length > 2
                ? Path.GetFullPath(args[2])
                : null;

            int passed = 0;
            for (int number = 1; number <= 6; number++)
            {
                string name = number.ToString("00") + ".gif";
                string path = Path.Combine(assetRoot, name);
                if (!File.Exists(path))
                {
                    return Fail(name, "file missing");
                }

                byte[] bytes = File.ReadAllBytes(path);
                using (Image image = Image.FromFile(path))
                {
                    int frames = image.GetFrameCount(FrameDimension.Time);
                    int minimumDelay;
                    int maximumDelay;
                    if (image.Width != 360 || image.Height != 360)
                    {
                        return Fail(name, "expected 360x360 dimensions");
                    }
                    if (frames != ExpectedFrameCounts[number - 1])
                    {
                        return Fail(name, "unexpected frame count " + frames);
                    }
                    if (!TryReadDelays(image, frames, out minimumDelay, out maximumDelay) ||
                        minimumDelay < 6 ||
                        maximumDelay > 7)
                    {
                        return Fail(name, "invalid animation timing");
                    }
                    if (!HasTransparencyFlag(bytes))
                    {
                        return Fail(name, "GIF transparency flag missing");
                    }
                    if (!HasInfiniteLoop(bytes))
                    {
                        return Fail(name, "GIF infinite-loop extension missing");
                    }

                    double edgeRatio = MaximumNeutralWhiteBoundaryRatio(image, frames);
                    if (edgeRatio >= 0.01)
                    {
                        return Fail(
                            name,
                            "neutral-white outer edge is " +
                            edgeRatio.ToString("P2") +
                            ", expected below 1%");
                    }
                    double paleEdgeRatio = MaximumPaleBoundaryRatio(image, frames);
                    if (paleEdgeRatio >= 0.01)
                    {
                        return Fail(
                            name,
                            "pale outer edge is " +
                            paleEdgeRatio.ToString("P2") +
                            ", expected below 1%");
                    }

                    double coverage = 1.0;
                    if (!String.IsNullOrWhiteSpace(originalRoot))
                    {
                        string originalPath = Path.Combine(originalRoot, name);
                        if (!File.Exists(originalPath))
                        {
                            return Fail(name, "original comparison asset missing");
                        }
                        using (Image original = Image.FromFile(originalPath))
                        {
                            if (original.GetFrameCount(FrameDimension.Time) != frames)
                            {
                                return Fail(name, "original frame count mismatch");
                            }
                            coverage = MinimumCoverageRatio(original, image, frames);
                        }
                        if (coverage < 0.97)
                        {
                            return Fail(
                                name,
                                "visible coverage retained only " + coverage.ToString("P2"));
                        }
                    }

                    Console.WriteLine(
                        "PASS {0}: 360x360, {1} frames, delay {2}-{3} ms, " +
                        "transparent, loop, white-edge {4}, pale-edge {5}, coverage {6}",
                        name,
                        frames,
                        minimumDelay * 10,
                        maximumDelay * 10,
                        edgeRatio.ToString("P2"),
                        paleEdgeRatio.ToString("P2"),
                        coverage.ToString("P2"));
                    passed++;
                }
            }

            Console.WriteLine("PASS: {0} cleaned animated GIF assets", passed);

            if (!String.IsNullOrWhiteSpace(displayRoot))
            {
                int displayPassed = 0;
                for (int number = 1; number <= 6; number++)
                {
                    string name = number.ToString("00") + ".gif";
                    string displayPath = Path.Combine(displayRoot, name);
                    string cleanedPath = Path.Combine(assetRoot, name);
                    if (!File.Exists(displayPath))
                    {
                        return Fail(name, "display asset missing");
                    }

                    byte[] bytes = File.ReadAllBytes(displayPath);
                    using (Image display = Image.FromFile(displayPath))
                    using (Image cleaned = Image.FromFile(cleanedPath))
                    {
                        int frames = display.GetFrameCount(FrameDimension.Time);
                        int minimumDelay;
                        int maximumDelay;
                        if (display.Width != 240 || display.Height != 240)
                        {
                            return Fail(name, "expected 240x240 display dimensions");
                        }
                        if (frames != ExpectedFrameCounts[number - 1])
                        {
                            return Fail(name, "unexpected display frame count " + frames);
                        }
                        if (!TryReadDelays(display, frames, out minimumDelay, out maximumDelay) ||
                            minimumDelay < 6 || maximumDelay > 7)
                        {
                            return Fail(name, "invalid display animation timing");
                        }
                        if (!DelaysMatch(cleaned, display, frames))
                        {
                            return Fail(name, "display per-frame timing changed");
                        }
                        if (!HasTransparencyFlag(bytes) || !HasInfiniteLoop(bytes))
                        {
                            return Fail(name, "display transparency or loop setting missing");
                        }

                        double edgeRatio = MaximumNeutralWhiteBoundaryRatio(display, frames);
                        double paleEdgeRatio = MaximumPaleBoundaryRatio(display, frames);
                        if (edgeRatio >= 0.01 || paleEdgeRatio >= 0.01)
                        {
                            return Fail(
                                name,
                                "display edge remains visible: white " +
                                edgeRatio.ToString("P2") + ", pale " +
                                paleEdgeRatio.ToString("P2"));
                        }

                        Console.WriteLine(
                            "PASS {0}: 240x240 exact display, {1} frames, delay {2}-{3} ms, " +
                            "transparent, loop, white-edge {4}, pale-edge {5}",
                            name,
                            frames,
                            minimumDelay * 10,
                            maximumDelay * 10,
                            edgeRatio.ToString("P2"),
                            paleEdgeRatio.ToString("P2"));
                        displayPassed++;
                    }
                }
                Console.WriteLine("PASS: {0} exact-size display GIF assets", displayPassed);
            }
            return 0;
        }

        private static int Fail(string name, string reason)
        {
            Console.Error.WriteLine("FAIL {0}: {1}", name, reason);
            return 1;
        }

        private static bool TryReadDelays(
            Image image,
            int frameCount,
            out int minimumDelay,
            out int maximumDelay)
        {
            minimumDelay = Int32.MaxValue;
            maximumDelay = 0;
            try
            {
                PropertyItem delay = image.GetPropertyItem(0x5100);
                if (delay.Value == null || delay.Value.Length < frameCount * 4)
                {
                    return false;
                }

                for (int frame = 0; frame < frameCount; frame++)
                {
                    int value = BitConverter.ToInt32(delay.Value, frame * 4);
                    if (value <= 0)
                    {
                        return false;
                    }
                    minimumDelay = Math.Min(minimumDelay, value);
                    maximumDelay = Math.Max(maximumDelay, value);
                }
                return true;
            }
            catch (ArgumentException)
            {
                return false;
            }
        }

        private static bool DelaysMatch(Image first, Image second, int frameCount)
        {
            try
            {
                PropertyItem firstDelay = first.GetPropertyItem(0x5100);
                PropertyItem secondDelay = second.GetPropertyItem(0x5100);
                if (firstDelay.Value == null || secondDelay.Value == null ||
                    firstDelay.Value.Length < frameCount * 4 ||
                    secondDelay.Value.Length < frameCount * 4)
                {
                    return false;
                }

                for (int frame = 0; frame < frameCount; frame++)
                {
                    if (BitConverter.ToInt32(firstDelay.Value, frame * 4) !=
                        BitConverter.ToInt32(secondDelay.Value, frame * 4))
                    {
                        return false;
                    }
                }
                return true;
            }
            catch (ArgumentException)
            {
                return false;
            }
        }

        private static double MaximumNeutralWhiteBoundaryRatio(Image image, int frameCount)
        {
            double maximum = 0.0;
            foreach (int frame in SampleFrames(frameCount))
            {
                using (Bitmap bitmap = RenderFrame(image, frame))
                {
                    int boundary = 0;
                    int neutralWhite = 0;
                    for (int y = 1; y < bitmap.Height - 1; y++)
                    {
                        for (int x = 1; x < bitmap.Width - 1; x++)
                        {
                            Color color = bitmap.GetPixel(x, y);
                            if (color.A == 0 || !TouchesTransparency(bitmap, x, y))
                            {
                                continue;
                            }
                            boundary++;
                            int minimum = Math.Min(color.R, Math.Min(color.G, color.B));
                            int maximumChannel = Math.Max(color.R, Math.Max(color.G, color.B));
                            if (minimum >= 240 && maximumChannel - minimum <= 24)
                            {
                                neutralWhite++;
                            }
                        }
                    }
                    if (boundary > 0)
                    {
                        maximum = Math.Max(maximum, neutralWhite / (double)boundary);
                    }
                }
            }
            return maximum;
        }

        private static double MinimumCoverageRatio(
            Image original,
            Image cleaned,
            int frameCount)
        {
            double minimum = 1.0;
            foreach (int frame in SampleFrames(frameCount))
            {
                using (Bitmap originalFrame = RenderFrame(original, frame))
                using (Bitmap cleanedFrame = RenderFrame(cleaned, frame))
                {
                    int originalVisible = CountVisible(originalFrame);
                    int cleanedVisible = CountVisible(cleanedFrame);
                    if (originalVisible <= 0)
                    {
                        return 0.0;
                    }
                    minimum = Math.Min(
                        minimum,
                        cleanedVisible / (double)originalVisible);
                }
            }
            return minimum;
        }

        private static double MaximumPaleBoundaryRatio(Image image, int frameCount)
        {
            double maximum = 0.0;
            foreach (int frame in SampleFrames(frameCount))
            {
                using (Bitmap bitmap = RenderFrame(image, frame))
                {
                    int boundary = 0;
                    int pale = 0;
                    for (int y = 1; y < bitmap.Height - 1; y++)
                    {
                        for (int x = 1; x < bitmap.Width - 1; x++)
                        {
                            Color color = bitmap.GetPixel(x, y);
                            if (color.A == 0 || !TouchesTransparency(bitmap, x, y))
                            {
                                continue;
                            }
                            boundary++;
                            int minimum = Math.Min(color.R, Math.Min(color.G, color.B));
                            if (minimum >= 170)
                            {
                                pale++;
                            }
                        }
                    }
                    if (boundary > 0)
                    {
                        maximum = Math.Max(maximum, pale / (double)boundary);
                    }
                }
            }
            return maximum;
        }

        private static int[] SampleFrames(int frameCount)
        {
            return new[] { 0, frameCount / 2, frameCount - 1 };
        }

        private static Bitmap RenderFrame(Image image, int frame)
        {
            image.SelectActiveFrame(FrameDimension.Time, frame);
            Bitmap bitmap = new Bitmap(
                image.Width,
                image.Height,
                PixelFormat.Format32bppArgb);
            using (Graphics graphics = Graphics.FromImage(bitmap))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.Clear(Color.Transparent);
                graphics.DrawImageUnscaled(image, 0, 0);
            }
            return bitmap;
        }

        private static bool TouchesTransparency(Bitmap bitmap, int x, int y)
        {
            return bitmap.GetPixel(x - 1, y).A == 0 ||
                   bitmap.GetPixel(x + 1, y).A == 0 ||
                   bitmap.GetPixel(x, y - 1).A == 0 ||
                   bitmap.GetPixel(x, y + 1).A == 0;
        }

        private static int CountVisible(Bitmap bitmap)
        {
            int count = 0;
            for (int y = 0; y < bitmap.Height; y++)
            {
                for (int x = 0; x < bitmap.Width; x++)
                {
                    if (bitmap.GetPixel(x, y).A > 0)
                    {
                        count++;
                    }
                }
            }
            return count;
        }

        private static bool HasTransparencyFlag(byte[] bytes)
        {
            for (int index = 0; index + 7 < bytes.Length; index++)
            {
                if (bytes[index] == 0x21 &&
                    bytes[index + 1] == 0xF9 &&
                    bytes[index + 2] == 0x04 &&
                    (bytes[index + 3] & 0x01) != 0)
                {
                    return true;
                }
            }
            return false;
        }

        private static bool HasInfiniteLoop(byte[] bytes)
        {
            byte[] marker =
            {
                (byte)'N', (byte)'E', (byte)'T', (byte)'S', (byte)'C', (byte)'A',
                (byte)'P', (byte)'E', (byte)'2', (byte)'.', (byte)'0'
            };
            for (int index = 0; index + marker.Length + 4 < bytes.Length; index++)
            {
                bool match = true;
                for (int offset = 0; offset < marker.Length; offset++)
                {
                    if (bytes[index + offset] != marker[offset])
                    {
                        match = false;
                        break;
                    }
                }
                if (match &&
                    bytes[index + marker.Length] == 0x03 &&
                    bytes[index + marker.Length + 1] == 0x01 &&
                    bytes[index + marker.Length + 2] == 0x00 &&
                    bytes[index + marker.Length + 3] == 0x00)
                {
                    return true;
                }
            }
            return false;
        }
    }
}

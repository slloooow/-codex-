using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

internal static class GifActionContactSheet
{
    private static int Main(string[] args)
    {
        if (args.Length != 2)
        {
            Console.Error.WriteLine("Usage: GifActionContactSheet <assets-dir> <output.png>");
            return 2;
        }

        string assetRoot = Path.GetFullPath(args[0]);
        string outputPath = Path.GetFullPath(args[1]);
        const int thumb = 240;
        const int samplesPerBackground = 6;
        const int columns = samplesPerBackground * 2;
        const int labelHeight = 30;
        const int rowGap = 12;
        int width = thumb * columns;
        int height = 6 * (thumb + labelHeight + rowGap);

        using (Bitmap sheet = new Bitmap(width, height, PixelFormat.Format32bppArgb))
        using (Graphics graphics = Graphics.FromImage(sheet))
        using (Font font = new Font("Microsoft YaHei UI", 11.0f, FontStyle.Bold))
        using (Brush textBrush = new SolidBrush(Color.FromArgb(45, 50, 103)))
        {
            graphics.Clear(Color.White);
            graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            graphics.SmoothingMode = SmoothingMode.AntiAlias;

            for (int number = 1; number <= 6; number++)
            {
                string name = number.ToString("00") + ".gif";
                string path = Path.Combine(assetRoot, name);
                using (Image gif = Image.FromFile(path))
                {
                    int frames = gif.GetFrameCount(FrameDimension.Time);
                    int y = (number - 1) * (thumb + labelHeight + rowGap);
                    for (int background = 0; background < 2; background++)
                    {
                        for (int column = 0; column < samplesPerBackground; column++)
                        {
                            int frame = (int)Math.Round(
                                (frames - 1) * column /
                                (double)(samplesPerBackground - 1));
                            gif.SelectActiveFrame(FrameDimension.Time, frame);
                            int outputColumn = (background * samplesPerBackground) + column;
                            Rectangle cell = new Rectangle(outputColumn * thumb, y, thumb, thumb);
                            if (background == 0)
                            {
                                DrawCheckerboard(graphics, cell, 15);
                            }
                            else
                            {
                                using (Brush dark = new SolidBrush(Color.FromArgb(28, 30, 43)))
                                {
                                    graphics.FillRectangle(dark, cell);
                                }
                            }
                            graphics.DrawImageUnscaled(gif, cell.X, cell.Y);
                            graphics.DrawString(
                                name + "  f" + frame.ToString("00") +
                                (background == 0 ? "  棋盘" : "  深色"),
                                font,
                                textBrush,
                                new PointF(cell.X + 8, y + thumb + 4));
                        }
                    }
                }
            }

            Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
            sheet.Save(outputPath, ImageFormat.Png);
        }

        Console.WriteLine(outputPath);
        return 0;
    }

    private static void DrawCheckerboard(Graphics graphics, Rectangle bounds, int size)
    {
        Color first = Color.FromArgb(244, 245, 249);
        Color second = Color.FromArgb(220, 223, 232);
        using (Brush firstBrush = new SolidBrush(first))
        using (Brush secondBrush = new SolidBrush(second))
        {
            for (int y = bounds.Top; y < bounds.Bottom; y += size)
            {
                for (int x = bounds.Left; x < bounds.Right; x += size)
                {
                    bool alternate = (((x - bounds.Left) / size) + ((y - bounds.Top) / size)) % 2 == 0;
                    graphics.FillRectangle(
                        alternate ? firstBrush : secondBrush,
                        x,
                        y,
                        Math.Min(size, bounds.Right - x),
                        Math.Min(size, bounds.Bottom - y));
                }
            }
        }
    }
}

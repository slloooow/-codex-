#!/usr/bin/env python3
"""Remove neutral white matte pixels from animated GIF silhouettes.

Normal application builds consume the checked-in files in DisplayAssets and
do not run this script. Re-running the cleanup requires Pillow and NumPy.
"""

from __future__ import annotations

import argparse
import os
from io import BytesIO
from pathlib import Path

import numpy as np
from PIL import Image


def adjacent_to_transparent(visible: np.ndarray) -> np.ndarray:
    adjacent = np.zeros_like(visible)
    adjacent[1:, :] |= ~visible[:-1, :]
    adjacent[:-1, :] |= ~visible[1:, :]
    adjacent[:, 1:] |= ~visible[:, :-1]
    adjacent[:, :-1] |= ~visible[:, 1:]
    return adjacent


def clean_frame(
    frame: Image.Image,
    minimum_channel: int,
    maximum_chroma: int,
) -> tuple[Image.Image, int]:
    pixels = np.array(frame.convert("RGBA"), dtype=np.uint8)
    rgb = pixels[:, :, :3].astype(np.int16)
    visible = pixels[:, :, 3] > 0
    channel_min = rgb.min(axis=2)
    chroma = rgb.max(axis=2) - channel_min

    removable = (
        visible
        & adjacent_to_transparent(visible)
        & (channel_min >= minimum_channel)
        & (chroma <= maximum_chroma)
    )
    visible[removable] = False

    pixels[:, :, 3] = np.where(visible, 255, 0).astype(np.uint8)
    return (
        Image.fromarray(pixels, mode="RGBA"),
        int(removable.sum()),
    )


def restore_outline(frame: Image.Image, radius: int = 3) -> tuple[Image.Image, int]:
    pixels = np.array(frame.convert("RGBA"), dtype=np.uint8)
    visible = pixels[:, :, 3] > 0
    boundary = visible & adjacent_to_transparent(visible)
    interior = visible & ~boundary
    rgb = pixels[:, :, :3].astype(np.int16)
    result = pixels.copy()
    changed = 0
    height, width = visible.shape

    for y, x in np.argwhere(boundary):
        top = max(0, int(y) - radius)
        bottom = min(height, int(y) + radius + 1)
        left = max(0, int(x) - radius)
        right = min(width, int(x) + radius + 1)
        candidate_mask = interior[top:bottom, left:right]
        if not candidate_mask.any():
            continue

        candidates = rgb[top:bottom, left:right][candidate_mask]
        candidate = candidates[candidates.mean(axis=1).argmin()]
        current = rgb[y, x]
        if current.mean() >= 110 and current.mean() - candidate.mean() >= 28:
            result[y, x, :3] = candidate.astype(np.uint8)
            changed += 1

    return Image.fromarray(result, mode="RGBA"), changed


def create_display_frame(
    frame: Image.Image,
    size: tuple[int, int] = (240, 240),
) -> tuple[Image.Image, int]:
    """Resize once in premultiplied alpha and harden the runtime silhouette.

    WinForms transparency keys are binary. Supplying an exact-size, binary-
    alpha frame avoids PictureBox interpolation against the green key color.
    The final outline pass replaces any pale resampling pixel that touches
    transparency with the darkest nearby visible color.
    """
    premultiplied = frame.convert("RGBa")
    try:
        resized = premultiplied.resize(size, Image.Resampling.LANCZOS)
        rgba = resized.convert("RGBA")
    finally:
        premultiplied.close()
        if "resized" in locals():
            resized.close()

    pixels = np.array(rgba, dtype=np.uint8)
    rgba.close()
    visible = pixels[:, :, 3] >= 128
    pixels[~visible] = 0
    pixels[visible, 3] = 255

    result = pixels.copy()
    boundary = visible & adjacent_to_transparent(visible)
    rgb = pixels[:, :, :3].astype(np.int16)
    changed = 0
    height, width = visible.shape
    for y, x in np.argwhere(boundary):
        top = max(0, int(y) - 3)
        bottom = min(height, int(y) + 4)
        left = max(0, int(x) - 3)
        right = min(width, int(x) + 4)
        candidate_mask = visible[top:bottom, left:right]
        candidates = rgb[top:bottom, left:right][candidate_mask]
        if candidates.size == 0:
            continue
        candidate = candidates[candidates.mean(axis=1).argmin()]
        current = rgb[y, x]
        if current.min() >= 150 and current.mean() - candidate.mean() >= 15:
            result[y, x, :3] = candidate.astype(np.uint8)
            changed += 1

    return Image.fromarray(result, mode="RGBA"), changed


def read_animation(path: Path) -> tuple[list[Image.Image], list[int], int, tuple[int, int]]:
    source = Image.open(path)
    frames: list[Image.Image] = []
    durations: list[int] = []
    loop = int(source.info.get("loop", 0))
    size = source.size
    try:
        for frame_index in range(source.n_frames):
            source.seek(frame_index)
            durations.append(int(source.info.get("duration", 70)))
            frames.append(source.convert("RGBA"))
    finally:
        source.close()
    return frames, durations, loop, size


def validate_animation(
    data: bytes,
    expected_frames: int,
    expected_durations: list[int],
    expected_loop: int,
    expected_size: tuple[int, int],
) -> None:
    result = Image.open(BytesIO(data))
    try:
        if result.n_frames != expected_frames:
            raise RuntimeError(
                f"frame count changed: {expected_frames} -> {result.n_frames}"
            )
        if result.size != expected_size:
            raise RuntimeError(f"size changed: {expected_size} -> {result.size}")
        if int(result.info.get("loop", 0)) != expected_loop:
            raise RuntimeError("loop setting changed")

        actual_durations: list[int] = []
        for frame_index in range(result.n_frames):
            result.seek(frame_index)
            actual_durations.append(int(result.info.get("duration", 0)))
        if actual_durations != expected_durations:
            raise RuntimeError("per-frame durations changed")
    finally:
        result.close()


def encode_animation(
    frames: list[Image.Image],
    durations: list[int],
    loop: int,
) -> bytes:
    encoded = BytesIO()
    try:
        frames[0].save(
            encoded,
            format="GIF",
            save_all=True,
            append_images=frames[1:],
            duration=durations,
            loop=loop,
            disposal=2,
            optimize=True,
        )
        return encoded.getvalue()
    finally:
        encoded.close()


def clean_animation(source_path: Path, destination_path: Path) -> None:
    frames, durations, loop, size = read_animation(source_path)
    first_frames: list[Image.Image] = []
    first_removed = 0
    second_removed = 0
    outline_restored = 0
    for frame in frames:
        cleaned, first_count = clean_frame(frame, 210, 38)
        first_frames.append(cleaned)
        first_removed += first_count
        frame.close()

    # Quantize once between the two spatial passes. GIF palette conversion can
    # turn a handful of pale lavender edge pixels back into neutral near-white;
    # performing the second threshold on that encoded palette keeps the final
    # result below the white-edge limit without removing a third pixel layer.
    try:
        intermediate_data = encode_animation(first_frames, durations, loop)
    finally:
        for frame in first_frames:
            frame.close()

    second_frames: list[Image.Image] = []
    with BytesIO(intermediate_data) as intermediate_stream:
        with Image.open(intermediate_stream) as intermediate:
            for frame_index in range(intermediate.n_frames):
                intermediate.seek(frame_index)
                cleaned, second_count = clean_frame(
                    intermediate.convert("RGBA"),
                    240,
                    24,
                )
                restored, restored_count = restore_outline(cleaned)
                cleaned.close()
                second_frames.append(restored)
                second_removed += second_count
                outline_restored += restored_count

    try:
        data = encode_animation(second_frames, durations, loop)
    finally:
        for frame in second_frames:
            frame.close()

    validate_animation(data, len(frames), durations, loop, size)
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = destination_path.with_suffix(".tmp.gif")
    temporary_path.write_bytes(data)
    os.replace(temporary_path, destination_path)
    print(
        f"{source_path.name}: {len(frames)} frames, "
        f"removed {first_removed}+{second_removed} edge pixels, "
        f"restored {outline_restored} outline pixels, "
        f"{source_path.stat().st_size}->{len(data)} bytes"
    )


def create_display_animation(source_path: Path, destination_path: Path) -> None:
    frames, durations, loop, _ = read_animation(source_path)
    display_frames: list[Image.Image] = []
    outline_restored = 0
    for frame in frames:
        display, changed = create_display_frame(frame)
        display_frames.append(display)
        outline_restored += changed
        frame.close()

    try:
        intermediate_data = encode_animation(display_frames, durations, loop)
    finally:
        for frame in display_frames:
            frame.close()

    # Palette quantization can reintroduce a few pale boundary colors. Reopen
    # the encoded animation and harden the exact-size frames one final time.
    final_frames: list[Image.Image] = []
    with BytesIO(intermediate_data) as intermediate_stream:
        with Image.open(intermediate_stream) as intermediate:
            for frame_index in range(intermediate.n_frames):
                intermediate.seek(frame_index)
                display, changed = create_display_frame(
                    intermediate.convert("RGBA"),
                    (240, 240),
                )
                final_frames.append(display)
                outline_restored += changed

    try:
        data = encode_animation(final_frames, durations, loop)
    finally:
        for frame in final_frames:
            frame.close()

    validate_animation(data, len(frames), durations, loop, (240, 240))
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = destination_path.with_suffix(".tmp.gif")
    temporary_path.write_bytes(data)
    os.replace(temporary_path, destination_path)
    print(
        f"{source_path.name}: 240x240 display animation, "
        f"restored {outline_restored} runtime outline pixels, {len(data)} bytes"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path, help="directory containing original GIFs")
    parser.add_argument("destination", type=Path, help="directory for cleaned GIFs")
    parser.add_argument(
        "--display-destination",
        type=Path,
        help="optional directory for exact-size 240x240 runtime GIFs",
    )
    args = parser.parse_args()

    source_root = args.source.resolve()
    destination_root = args.destination.resolve()
    if source_root == destination_root:
        parser.error("source and destination directories must differ")

    gif_paths = sorted(source_root.glob("*.gif"))
    if len(gif_paths) != 6:
        parser.error(f"expected 6 GIF files, found {len(gif_paths)}")

    for source_path in gif_paths:
        clean_animation(source_path, destination_root / source_path.name)

    if args.display_destination is not None:
        display_root = args.display_destination.resolve()
        if display_root in (source_root, destination_root):
            parser.error("display destination must be a separate directory")
        for cleaned_path in sorted(destination_root.glob("*.gif")):
            create_display_animation(cleaned_path, display_root / cleaned_path.name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

using System;

namespace CodexQuotaPet
{
    internal sealed class QuotaSpeechContent
    {
        public string CompactText { get; set; }
        public string Prefix { get; set; }
        public string Highlight { get; set; }
        public string Suffix { get; set; }
        public string Detail { get; set; }

        public string Dialogue
        {
            get
            {
                return (Prefix ?? String.Empty) +
                       (Highlight ?? String.Empty) +
                       (Suffix ?? String.Empty);
            }
        }
    }

    internal static class QuotaSpeech
    {
        public static QuotaSpeechContent Build(
            QuotaSnapshot snapshot,
            bool stale,
            bool loading,
            string status,
            DateTime nowUtc)
        {
            if (stale)
            {
                if (snapshot == null)
                {
                    return Content(
                        "!",
                        "信号藏起来了，我去找找～",
                        String.Empty,
                        String.Empty,
                        "稍后会自动重试");
                }

                if (snapshot.IsUnlimited)
                {
                    return Content(
                        "∞!",
                        "信号藏起来了，我去找找～",
                        String.Empty,
                        String.Empty,
                        "上次状态：无限 · 等待更新");
                }

                int cached = RoundedPercent(snapshot.RemainingPercent);
                return Content(
                    cached + "%!",
                    "信号藏起来了，我去找找～",
                    String.Empty,
                    String.Empty,
                    "上次额度 " + cached + "% · 等待更新");
            }

            if (loading || snapshot == null)
            {
                return Content(
                    "…",
                    "谜底在路上，再等我一下～",
                    String.Empty,
                    String.Empty,
                    String.IsNullOrWhiteSpace(status) ? "正在连接 Codex…" : status);
            }

            if (snapshot.IsUnlimited)
            {
                return Content(
                    "∞",
                    "今天的时间对我们格外慷慨。",
                    String.Empty,
                    String.Empty,
                    "当前没有额度限制");
            }

            int remaining = RoundedPercent(snapshot.RemainingPercent);
            string prefix;
            string suffix;
            if (remaining >= 70)
            {
                prefix = "还有 ";
                suffix = "，时间对我们很慷慨。";
            }
            else if (remaining >= 40)
            {
                prefix = "还剩 ";
                suffix = "，再陪我一会儿吧～";
            }
            else if (remaining >= 15)
            {
                prefix = "只剩 ";
                suffix = " 了，别太勉强自己。";
            }
            else if (remaining >= 1)
            {
                prefix = "仅余 ";
                suffix = "……留给重要的事吧。";
            }
            else
            {
                return Content(
                    "0%",
                    "额度归零，问答暂时结束～",
                    String.Empty,
                    String.Empty,
                    Countdown(snapshot.ResetAtUtc, nowUtc));
            }

            return Content(
                remaining + "%",
                prefix,
                remaining + "%",
                suffix,
                Countdown(snapshot.ResetAtUtc, nowUtc));
        }

        private static QuotaSpeechContent Content(
            string compact,
            string prefix,
            string highlight,
            string suffix,
            string detail)
        {
            return new QuotaSpeechContent
            {
                CompactText = compact,
                Prefix = prefix,
                Highlight = highlight,
                Suffix = suffix,
                Detail = detail
            };
        }

        private static int RoundedPercent(double value)
        {
            value = Math.Max(0.0, Math.Min(100.0, value));
            return (int)Math.Round(value, MidpointRounding.AwayFromZero);
        }

        private static string Countdown(DateTime resetAtUtc, DateTime nowUtc)
        {
            TimeSpan remaining = resetAtUtc - nowUtc;
            if (remaining <= TimeSpan.Zero)
            {
                return "正在刷新额度…";
            }

            if (remaining.TotalDays >= 1.0)
            {
                int days = (int)Math.Floor(remaining.TotalDays);
                return String.Format(
                    "{0}天 {1:00}:{2:00}:{3:00} 后重置",
                    days,
                    remaining.Hours,
                    remaining.Minutes,
                    remaining.Seconds);
            }

            int hours = (int)Math.Floor(remaining.TotalHours);
            return String.Format(
                "{0:00}:{1:00}:{2:00} 后重置",
                hours,
                remaining.Minutes,
                remaining.Seconds);
        }
    }
}

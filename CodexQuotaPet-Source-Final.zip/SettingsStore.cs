using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Script.Serialization;
using Microsoft.Win32;

namespace CodexQuotaPet
{
    internal sealed class PetSettings
    {
        public bool HasPosition { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public string Monitor { get; set; }
        public bool ClickThrough { get; set; }
    }

    internal static class SettingsStore
    {
        private const string RunValueName = "CodexQuotaPet";

        public static string InstallDirectory
        {
            get
            {
                return Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "CodexQuotaPet");
            }
        }

        public static string SettingsPath
        {
            get { return Path.Combine(InstallDirectory, "settings.json"); }
        }

        public static PetSettings Load()
        {
            try
            {
                if (!File.Exists(SettingsPath))
                {
                    return new PetSettings();
                }

                string json = File.ReadAllText(SettingsPath);
                PetSettings settings = new JavaScriptSerializer().Deserialize<PetSettings>(json);
                return settings ?? new PetSettings();
            }
            catch (Exception)
            {
                return new PetSettings();
            }
        }

        public static void Save(PetSettings settings)
        {
            try
            {
                Directory.CreateDirectory(InstallDirectory);
                string json = new JavaScriptSerializer().Serialize(settings);
                File.WriteAllText(SettingsPath, json);
            }
            catch (Exception)
            {
                // Position persistence must never terminate the pet.
            }
        }

        public static bool IsAutoStartEnabled()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(
                    @"Software\Microsoft\Windows\CurrentVersion\Run", false))
                {
                    return key != null && key.GetValue(RunValueName) != null;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static void SetAutoStart(bool enabled)
        {
            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(
                @"Software\Microsoft\Windows\CurrentVersion\Run"))
            {
                if (key == null)
                {
                    throw new InvalidOperationException("无法打开 Windows 启动项");
                }

                if (enabled)
                {
                    string executable = System.Reflection.Assembly.GetExecutingAssembly().Location;
                    key.SetValue(RunValueName, "\"" + executable + "\"");
                }
                else
                {
                    key.DeleteValue(RunValueName, false);
                }
            }
        }
    }
}
